<?php
print "<html>";
print "<head>";
print "<title>WP Installation Page</title>";
print "<style type=\"text/css\">";
//print "       body{ background-color:#5a6c89;}";
print "       .style1";
print "       {";
print "           width: 25%;";
print "           margin-left:5px;";
print "          ";
print "       }";
print "       .style2";
print "       {";
print "           width: 66px;";
print "       }";
print "       .style3";
print "       {";
print "           width: 100%;";
print "       }";
print "       </style>";

print "</head>";
print "<body style=\"text-shadow:#000 1px -1px 2px; top:0px;  \">";

print "<iframe src =\"sessionstarter.php\" width=\"100%\" height=\"100%\" frameborder=\"0\" scrolling=\"no\" >";
print " <p>Your browser does not support iframes.</p>\n";
print "/iframe>\n";
print "\n";

print "</html>";
print "</body>";
?>