<?php
//this is my wp_config.php file
echo "hello god";
?>