<?php
//if (function_exists('imagecreate')) {
  // echo "GD Library is enabled <br>\r\n"; // Hide this when captcha everything works fine
//} else {
//   echo "Sorry, you need to enable GD library first";
//}
    
include("opendb.php");

if ((isset($_POST['login'])) AND (isset($_POST['serial'])))  {
// you should inspect these variables before passing off to mySQL
$login = mysql_real_escape_string($_POST['login']);
$serial = mysql_real_escape_string($_POST['serial']);

  
$result = mysql_query("SELECT * FROM users WHERE Login='$login' AND Serial='$serial'") or die(mysql_error());
//Alternative way for unit testing
//$row = mysql_fetch_array( $result );
//$validateUser = $row['username'];
//$validatePass = $row['password'];
//$id = (int)$row['id'];
//echo "id="+$id;
    if (mysql_num_rows($result)) // or if($id = 1) //for unit test
    {
           //check for insufficent Saldo(balance)
		   
		   $result = mysql_query("SELECT * FROM users WHERE Login='$login' AND Serial='$serial' AND Saldo>0 ") or die(mysql_error());
		   if (mysql_num_rows($result))
		   {
		   //log in the user
	
           session_start();
           $_SESSION['userserial'] = $serial;
		   //$_SESSION['userpass']= "yes";
	
           //echo "Start User : ".$_SESSION['username']; //for unit testing only
	       //print "Login sucessfull ..! ";//for unit testing only
	       //print "<a href = \"admin.php\" target=\"_top\" style=\"font-size:75px;\">Click This Link To Proceed to Admin Panel!</a>";
	       //Redirect to ftp
	       printf("<script>location.href='ftpinput.php'</script>");	
		   }
		   else
		   {
		   	include("loginform.php");
            print "	<div style=\"margin-left: 337px; width:310px;\">";
            print "                          <br/><br/><div style = \"display:block; background-color:#ffebe8; border:1px solid #cc0000;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Error:</b> Insufficent Balance in A/C!</div><br/><br/>";
            print "               </div>";
		   }
		   
		   

    }
    else  
	{  include("loginform.php");
print "	<div style=\"margin-left: 337px; width:310px;\">";
print "                          <br/><br/><div style = \"display:block; background-color:#ffebe8; border:1px solid #cc0000;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Error:</b> Invalid Username/Password!</div><br/><br/>";
print "               </div>";
	}
	
} 
else {
 include("loginform.php");
}
mysql_close($conn);
?>