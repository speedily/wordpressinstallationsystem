<?php
include("sessionchecker.php");

//generate $userid
include("opendb.php"); 

$lastid = 0;
$userid = 0;

$result = mysql_query("SELECT MAX(ID) FROM users") or die(mysql_error());
$row = mysql_fetch_array($result);
$lastid=$row["MAX(ID)"];

$userid = $lastid + 1;

mysql_close($conn);

//generate $serial
    function assign_rand_value($num)
    {
    // accepts 1 - 36
    switch($num)
    {
    case "1":
    $rand_value = "A";
    break;
    case "2":
    $rand_value = "B";
    break;
    case "3":
    $rand_value = "C";
    break;
    case "4":
    $rand_value = "D";
    break;
    case "5":
    $rand_value = "E";
    break;
    case "6":
    $rand_value = "F";
    break;
    case "7":
    $rand_value = "G";
    break;
    case "8":
    $rand_value = "H";
    break;
    case "9":
    $rand_value = "I";
    break;
    case "10":
    $rand_value = "J";
    break;
    case "11":
    $rand_value = "K";
    break;
    case "12":
    $rand_value = "L";
    break;
    case "13":
    $rand_value = "M";
    break;
    case "14":
    $rand_value = "N";
    break;
    case "15":
    $rand_value = "1";//(O)Capital o removed for confusion
    break;
    case "16":
    $rand_value = "P";
    break;
    case "17":
    $rand_value = "Q";
    break;
    case "18":
    $rand_value = "R";
    break;
    case "19":
    $rand_value = "S";
    break;
    case "20":
    $rand_value = "T";
    break;
    case "21":
    $rand_value = "U";
    break;
    case "22":
    $rand_value = "V";
    break;
    case "23":
    $rand_value = "W";
    break;
    case "24":
    $rand_value = "X";
    break;
    case "25":
    $rand_value = "Y";
    break;
    case "26":
    $rand_value = "Z";
    break;
    case "27":
    $rand_value = "A";//(0)Zero removed for confusion
    break;
    case "28":
    $rand_value = "1";
    break;
    case "29":
    $rand_value = "2";
    break;
    case "30":
    $rand_value = "3";
    break;
    case "31":
    $rand_value = "4";
    break;
    case "32":
    $rand_value = "5";
    break;
    case "33":
    $rand_value = "6";
    break;
    case "34":
    $rand_value = "7";
    break;
    case "35":
    $rand_value = "8";
    break;
    case "36":
    $rand_value = "9";
    break;
    }
    return $rand_value;
    }

    function get_rand_id($length)
    {
    if($length>0)
    {
    $rand_id="";
    for($i=1; $i<=$length; $i++)
    {
    mt_srand((double)microtime() * 1000000);
    $num = mt_rand(1,36);
    $rand_id .= assign_rand_value($num);
    }
    }
    return $rand_id;
    }

    function UniqueSerial($s){
    include("opendb.php");
    // make sure this salt value is unique
    $sql = "SELECT * FROM users WHERE Serial = \"$s\"";
    $result = mysql_query($sql);
    if(!$result) die("mysql error: " . mysql_error());
    $num = mysql_num_rows($result);
    mysql_close($conn);
    if($num>0) UniqueSerial(get_rand_id(50));
    else return $s;
    }

$serial= UniqueSerial(get_rand_id(20)); //(20 is the length of the serial number)


// if form submit 
if ((isset($_POST['name'])) AND (isset($_POST['surname'])) AND (isset($_POST['email'])) AND (isset($_POST['login'])) AND (isset($_POST['domain'])) AND (isset($_POST['installations'])))  
{ 

// 1>find values of text box that are submitted 
$name = $_POST['name'];
$surname= $_POST['surname'];
$useremail = $_POST['email'];
$login = $_POST['login'];
$domain = $_POST['domain'];
$installations = $_POST['installations'];

// 2>find checkbox values, combine them with '@' and '.' and store in a string
$curp = "";         
		 if(isset($_POST['formDoor']))
         {
		    $aDoor = $_POST['formDoor'];
    
            $N = count($aDoor);
            ////echo("You selected $N door(s): ");
            
			include("opendb.php");
            for($i=0; $i < $N; $i++)
            {
            //echo($aDoor[$i] . " ");
            $curp = $aDoor[$i];
            $result = mysql_query("SELECT name FROM plugins WHERE ref='".$curp."'")  or die(mysql_error());
			$row = mysql_fetch_array($result);
			$plugins = $plugins."@".$row["name"];
            }
            mysql_close($conn);
	        
         }

//print "final:".$plugins; for unit testing only


// 3>add results to db
include("opendb.php");

    //$userid, $serial, $plugins;
$sql="INSERT INTO users(ID,Name,Surname,Email,Login,Domain,Installations,Used,Saldo,Serial,pluginsallowed)
      Values($userid,'$name','$surname','$useremail','$login','$domain',$installations,0,$installations,'$serial','$plugins')";

if (!mysql_query($sql,$conn))
  {
  die('Error: ' . mysql_error());
  }
//echo "records updated";

mysql_close($conn);

// 4>send mail to user with details
$headers  = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";

//     $to = $useremail;
	 $to = "To: ".$name." <".$useremail.">";
     $subject = "Gefuso.com - Wordpress Installation System Activation Details!";	 
     $message = "Hello ".$name.",<br/>
	             <p><big>Congratulations!!</big> Your a/c has been activated for Wordpress Installation usage.</p><br/>
				 <p>Your <b>Login ID</b> is:<b>".$login."</b></p>
				 <p>Your <b>Activation Serial</b> number is:<b>".$serial."</b></p>
				 <b>NOTE:</b> All letters are a combination in FULL CAPITALS and NUMBERS to avoid confusion in reading.</p>
				 <p>Please note down your Activation Serial. It is very important in the process.</p>
				 <p>You can now goto <a href=\"http://www.gefuso.com/wpinstallation \">www.gefuso.com/wpinstallation</a> and install wordpress with many themes and plugins we have for you.<br/>
				 If you loose your <b>Activation Serial</b> number, then contact me at my e-mail mentioned at the bottom of the message.</p>
				 <p>Best Regards,<br/>
				 Fabio - Fabio [at] Gefuso.com</p>";
     
	 $headers .= "From: Gefuso Support <support@gefuso.com>";
     @mail($to,$subject,$message,$headers);
   //echo "Mail Sent.";
// 4.end
  //5. Show Sucess Message
  printf("<script>location.href='sucess.php?type=useradded&id=$userid'</script>");
    
}

print "<div style=\"width:835px; height:490px; font-family:Arial; \">";

print "<div style=\"background-color:#c8e2ff; display:block; width:835px; height:15px; padding-top:10px; padding-bottom:10px;\">";
print "<a style=\"padding-left:20px;font-weight:bold; font-size:14px;\">Add New User</a>";
print "</div>";

print "<div style=\"background-color:#e3f3ff; display:block; width:835px; height:453px;\">";
print "<div style = \"padding-left:20px; padding-top:10px;\">";
print "On this page, you can add a new user in your <b>WPInstallation</b> system!";

print "<br/><br/>";
print ("<form name=\"sports\" action=\"$PHP_SELF\" method=\"POST\">");
print "<table class=\"style1\">
            <tr>
                <td style=\"width: 55px;\">
                ID:</td>
                <td style=\"width: 250px;\">
                ".$userid."</td>
                <td>
                    <b>Note:</b> System Generated <b>ID</b> & <b>Serial</b> will be visible here for every
                </td>
            </tr>
            <tr>
                <td style=\"width: 55px;\">
                Serial:</td>
                <td style=\"width: 250px;\">
                ".$serial."</td>
                <td>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; new user you add,thus avoiding any kind of conflict in database.</td>
            </tr>
        </table>
        
<br/>
<table style=\"width: 100%;\">
        <tr>
            <td style=\"width: 55px;\">
                Name:
            </td>
            <td class=\"style2\">
                <input type=\"text\" style=\"width: 150px;\" name=\"name\" />&nbsp; </td>
			<td style =\"width: 55px;\">
                Surname:</td>
            <td class=\"style2\">
                <input type=\"text\" style=\"width: 150px;\" name=\"surname\" /></td>
			<td style=\"width: 55px;\">
                Email:
            </td>
            <td class=\"style2\">
                <input type=\"text\" style=\"width: 150px;\" name=\"email\" /></td>
        </tr>
        <tr>
            <td style=\"width: 55px;\">
                Login:             </td>
            <td class=\"style2\">
                <input type=\"text\" style=\"width: 150px;\" name=\"login\" /></td>
			<td style=\"width: 55px;\">
                Domain:</td>
            <td class=\"style2\">
                <input type=\"text\" style=\"width: 150px;\" name=\"domain\" /></td>
        
        
            <td style=\"width: 55px;\">
                Installations:</td>
            <td class=\"style2\">
                <input type=\"text\" style=\"width: 150px;\" name=\"installations\" /></td>
        </tr>
        </table>
<br/><b>Plugins Allowed:</b><br/>";
//show plugins
include("opendb.php");

print "<table>";
 $result = mysql_query("SELECT name,ref FROM plugins")  or die(mysql_error());
  while ($row = mysql_fetch_array($result)) {
          //  ^ must be a single '=' !!!!
      print "<tr>";
	  print "<td><input type=\"checkbox\" name=\"formDoor[]\" value=\"".$row["ref"]."\" />" . $row["name"] . "</td>";
	  $row = mysql_fetch_array($result);
	  print "<td><input type=\"checkbox\" name=\"formDoor[]\" value=\"".$row["ref"]."\" />" . $row["name"] . "</td>";
	  $row = mysql_fetch_array($result);
	  print "<td><input type=\"checkbox\" name=\"formDoor[]\" value=\"".$row["ref"]."\" />" . $row["name"] . "</td>";
	  $row = mysql_fetch_array($result);
	  print "<td><input type=\"checkbox\" name=\"formDoor[]\" value=\"".$row["ref"]."\" />" . $row["name"] . "</td>";
      print "</tr>";
  } 
print "</table>";
mysql_close($conn);
print (" <input type=\"submit\" value=\"Submit Entry\" style=\"background-color:#CCCCCC;height:25px;width:150px; margin-left:570px; \">");
print "<br/><br/><b>NOTE:</b> The <b>Submit Entry</b> button above will <b>ADD USER</b> in system and also <b>SEND EMAIL</b> with Serial &amp; Instructions <br/>to this added user in one shot. But make sure the E-mail ID is a valid/working one, else this can cause critical errors.";
print "</form>";
print "<script> var objCheckBoxes = document.forms['sports'].elements['formDoor[]']; objCheckBoxes['q-and-a.0.2.1.zip'].checked = true;</script>";
print "</div></div></div>";
?>