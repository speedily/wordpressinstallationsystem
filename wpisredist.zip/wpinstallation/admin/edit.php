<?php
include("sessionchecker.php");

print "<div style=\"width:835px; height:490px; font-family:Arial; \">";

print "<div style=\"background-color:#c8e2ff; display:block; width:835px; height:15px; padding-top:10px; padding-bottom:10px;\">";
print "<a style=\"padding-left:20px;font-weight:bold; font-size:14px;\">Edit Existing User</a>";
print "</div>";

print "<div style=\"background-color:#e3f3ff; display:block; width:835px; height:453px;\">";
print "<div style = \"padding-left:20px; padding-top:10px; padding-right:20px;\">";
print "On this page, you can edit a user of your <b>WPInstallation</b> system!";

$id=$_REQUEST['id'];  

// if form submit 
if ((isset($_POST['name'])) AND (isset($_POST['surname'])) AND (isset($_POST['email'])) AND (isset($_POST['login'])) AND (isset($_POST['domain'])) AND (isset($_POST['installations'])))  
{ 

// 1>find values of text box that are submitted 
$name = $_POST['name'];
$surname= $_POST['surname'];
$useremail = $_POST['email'];
$login = $_POST['login'];
$domain = $_POST['domain'];
$installations = $_POST['installations'];

//get used
include("opendb.php");
$result = mysql_query("SELECT Used FROM users WHERE ID='".$id."'")  or die(mysql_error());
$row = mysql_fetch_array($result);
$used= $row["Used"];
mysql_close($conn);
//echo "used".$used; //for unit testing only
//calculate saldo
$saldo = $installations - $used;
//echo "saldo".$saldo; //for unit testing only

// 2>find checkbox values, combine them with '@' and '.' and store in a string
$curp = "";         
		 if(isset($_POST['formDoor']))
         {
		    $aDoor = $_POST['formDoor'];
    
            $N = count($aDoor);
            //echo("You selected $N door(s): "); //for unit testing only
            
			include("opendb.php");
            for($i=0; $i < $N; $i++)
            {
            //echo($aDoor[$i] . " ");
            $curp = $aDoor[$i];
            $result = mysql_query("SELECT name FROM plugins WHERE ref='".$curp."'")  or die(mysql_error());
			$row = mysql_fetch_array($result);
			$plugins = $plugins."@".$row["name"];
            }
            mysql_close($conn);
	        
         }

//print "final:".$plugins; for unit testing only


// 3>add results to db
include("opendb.php");

    //$userid, $serial, $plugins;
//Also update Saldo because Changing number of Installations should affect Saldo(balance) as in formula [Saldo = Installations - Used(from DB)]
//Note:Saldo is calculated beforehand see above at //echo "saldo".$saldo;

$sql= "UPDATE       users 
       SET  Name = '".$name."', Surname = '".$surname."', Email = '".$useremail."', Login = '".$login."', Domain = '".$domain."', Installations = '".$installations."', Saldo='".$saldo."', pluginsallowed= '".$plugins."'
       WHERE        (ID = ".$id.")";
//echo $sql;	  

if (!mysql_query($sql,$conn))
    {
        die('Error: ' . mysql_error());
    }
    //echo "records updated";
	mysql_close($conn);
	
	printf("<script>location.href='sucess.php?type=useredited&id=$id'</script>");
}



if (isset($id) && !empty($id))
{
//do work();
print "<br/><br/>";
include("opendb.php");

$result = mysql_query("SELECT * FROM users WHERE id=".$id."")  or die(mysql_error());
$row = mysql_fetch_array($result);

print ("<form action=\"$PHP_SELF\" method=\"POST\">");
print "<table class=\"style1\">
            <tr>
                <td style=\"width: 55px;\">
                ID:</td>
                <td style=\"width: 250px;\">
                ".$row["ID"]."</td>
				<input type=\"hidden\" name=\"id\" value=\"";
				echo $id;
				print "\">
                <td>
                    <b>Note:</b> System Generated <b>ID</b> & <b>Serial</b> will be visible here for every
                </td>
            </tr>
            <tr>
                <td style=\"width: 55px;\">
                Serial:</td>
                <td style=\"width: 250px;\">
                ".$row["Serial"]."</td>
                <td>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; user you edit,thus avoiding any kind of conflict in database.</td>
            </tr>
        </table>
        
<br/>
<table style=\"width: 100%;\">
        <tr>
            <td style=\"width: 55px;\">
                Name:
            </td>
            <td class=\"style2\">";
			$name = $row["Name"];
			print "
                <input type=\"text\" style=\"width: 150px;\" name=\"name\" value=\"$name\" />&nbsp; </td>
			<td style =\"width: 55px;\">
                Surname:</td>
            <td class=\"style2\">";
			$surname=$row["Surname"];
			print "
                <input type=\"text\" style=\"width: 150px;\" name=\"surname\" value=\"$surname\" /></td>
			<td style=\"width: 55px;\">
                Email:
            </td>";
			$email=$row["Email"];
			print "
            <td class=\"style2\">
                <input type=\"text\" style=\"width: 150px;\" name=\"email\" value=\"$email\" /></td>
        </tr>
        <tr>
            <td style=\"width: 55px;\">
                Login:             </td>
            <td class=\"style2\">";
			$login = $row["Login"];
			print "
                <input type=\"text\" style=\"width: 150px;\" name=\"login\" value=\"$login\" /></td>
			<td style=\"width: 55px;\">
                Domain:</td>";
			$domain = $row["Domain"];
			print "
            <td class=\"style2\">
                <input type=\"text\" style=\"width: 150px;\" name=\"domain\" value=\"$domain\" /></td>
        
        
            <td style=\"width: 55px;\">
                Installations:</td>";
			$installations = $row["Installations"];
			print "
            <td class=\"style2\">
                <input type=\"text\" style=\"width: 150px;\" name=\"installations\" value=\"$installations\" />
				</td>
        </tr>
        </table>";
mysql_close($conn);              
print "<br/><b>Plugins Allowed:</b><br/>";
//show plugins
include("opendb.php");

print "<table>";
 $result = mysql_query("SELECT name,ref FROM plugins")  or die(mysql_error());
  while ($row = mysql_fetch_array($result)) {
          //  ^ must be a single '=' !!!!
      print "<tr>";
	  print "<td><input type=\"checkbox\" name=\"formDoor[]\" value=\"".$row["ref"]."\" id=\"".$row["name"]."\" />" . $row["name"] . "</td>";
	  $row = mysql_fetch_array($result);
	  print "<td><input type=\"checkbox\" name=\"formDoor[]\" value=\"".$row["ref"]."\" id=\"".$row["name"]."\" />" . $row["name"] . "</td>";
	  $row = mysql_fetch_array($result);
	  print "<td><input type=\"checkbox\" name=\"formDoor[]\" value=\"".$row["ref"]."\" id=\"".$row["name"]."\" />" . $row["name"] . "</td>";
	  $row = mysql_fetch_array($result);
	  print "<td><input type=\"checkbox\" name=\"formDoor[]\" value=\"".$row["ref"]."\" id=\"".$row["name"]."\" />" . $row["name"] . "</td>";
      print "</tr>";
  } 
print "</table>";
mysql_close($conn);
//get the list of plugins selected
//check plugins
include("opendb.php");
$result = mysql_query("SELECT pluginsallowed FROM users WHERE id=".$id."")  or die(mysql_error());
$row = mysql_fetch_array($result);
$plugins=$row["pluginsallowed"];
$play = explode("@", $plugins);
print "
<script type=\"text/javascript\">

function my_code(){
";
foreach($play as $key => $value )
{
//echo "Key: $key; Value: $value<br />\n"; //for unit testing only
        if ($key>0)
        {
            print "document.getElementById(\"$value\").checked=true;";	
        }

}
print "
}

window.onload=my_code;
</script>";
mysql_close($conn);              
//end of check plugins
print ("<input type=\"submit\" value=\"Submit Changes\" style=\"background-color:#CCCCCC;height:25px;width:150px; margin-left:570px; \">");
print "";
print "</form>";
}

print "<br/><br/>";
print "</div></div></div>";
?>