<?php
include '../config.php';

$conn = mysql_connect($dbhost, $dbuser, $dbpass);

if (!$conn) {
    die('Error connecting to mysql. Could not connect: ' . mysql_error());
}
// echo "Connected successfully"; // Hide this when db everything works fine

mysql_select_db($dbname);
?>