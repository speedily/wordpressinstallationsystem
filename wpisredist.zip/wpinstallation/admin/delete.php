<?php
include("sessionchecker.php");

print "<div style=\"width:835px; height:490px; font-family:Arial; \">";

print "<div style=\"background-color:#c8e2ff; display:block; width:835px; height:15px; padding-top:10px; padding-bottom:10px;\">";
print "<a style=\"padding-left:20px;font-weight:bold; font-size:14px;\">Delete Existing User</a>";
print "</div>";

print "<div style=\"background-color:#e3f3ff; display:block; width:835px; height:453px;\">";
print "<div style = \"padding-left:20px; padding-top:10px; padding-right:20px;\">";
print "On this page, you can delete a user of your <b>WPInstallation</b> system!";

$id=$_REQUEST['id'];  

if (isset($id) && !empty($id))
{
//confirmdelete();
print "<p>Do you want to delete the following user?</p>";

include("opendb.php");

$result = mysql_query("SELECT * FROM users WHERE id=".$id."")  or die(mysql_error());
$row = mysql_fetch_array($result);
 print "<p style=\"background-color:#3887c4;\">
    
        <table style=\"width: 795px; text-align:center;\">
            <tr>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    ID</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["ID"]."</td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Name</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Name"]."</td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Surname</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Surname"]."</td>
            </tr>
            <tr>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Email</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Email"]."</td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Login</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Login"]."</td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Domain</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Domain"]."</td>
            </tr>
            <tr>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Installations</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Installations"]."</td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Used</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Used"]."</td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Saldo</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Saldo"]."</td>
            </tr>
            <tr>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Serial</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Serial"]."</td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    </td>
                <td style=\"background-color: #f0f0f0;\">
                    </td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    </td>
                <td style=\"background-color: #f0f0f0;\">
                    </td>
            </tr>
        </table>
    
    </p>";
mysql_close($conn);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        

//deleteform(); 
print "<form action=\"$PHP_SELF\" method=\"POST\">";
print "<div style=\"text-align:center;\"><input type=\"submit\" name=\"yes\" value=\"Yes\" style= \"height:35px; width:60px;\" >";
print "<input type=\"hidden\" name=\"id\" value=\"";
				echo $id;
print "\">";
print "<input type=\"submit\" name=\"no\" value=\"No\" style= \"height:35px; width:60px;\" ></div>";
print "</form>";
}

if($_POST['yes'] == 'Yes') 
{
 //delete it
include("opendb.php");
mysql_query("DELETE FROM users WHERE ID='".$id."'"); 
mysql_close($conn);
//redirect to view page
//printf("<script>location.href='view.php'</script>");
printf("<script>location.href='sucess.php?type=userdeleted&id=$id'</script>");
}
elseif ($_POST['no'] == 'No') 
{
 //redirect to view page
 printf("<script>location.href='view.php'</script>");
}


print "<br/><br/>";
print "</div></div></div>";
?>