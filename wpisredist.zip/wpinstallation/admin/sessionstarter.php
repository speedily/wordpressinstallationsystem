<?php
//if (function_exists('imagecreate')) {
  // echo "GD Library is enabled <br>\r\n"; // Hide this when captcha everything works fine
//} else {
//   echo "Sorry, you need to enable GD library first";
//}
    
include("opendb.php");

if ((isset($_POST['username'])) AND (isset($_POST['password'])))  {
$auser = mysql_real_escape_string($_POST['username']);
$apass = mysql_real_escape_string($_POST['password']);

  // you should inspect these variables before passing off to mySQL
$result = mysql_query("SELECT * FROM admin WHERE AdminUsername='$auser' AND AdminPassword='$apass'") or die(mysql_error());
//Alternative way for unit testing
//$row = mysql_fetch_array( $result );
//$validateUser = $row['username'];
//$validatePass = $row['password'];
//$id = (int)$row['id'];
//echo "id="+$id;
    if (mysql_num_rows($result)) // or if($id = 1) //for unit test
    {
    //log in the user
	
    session_start();
    $_SESSION['username'] = "Admin";
	
    //echo "Start User : ".$_SESSION['username']; //for unit testing only
    
	
	
	//print "Login sucessfull ..! ";//for unit testing only
	//print "<a href = \"admin.php\" target=\"_top\" style=\"font-size:75px;\">Click This Link To Proceed to Admin Panel!</a>";
	//Redirect to admin
	printf("<script>location.href='admin.php'</script>");

    }
    else  
	{  include("loginform.php");
print "	<div style=\"margin-left: 312px; width:250px;\">";
print "                          <br/><br/><div style = \"display:block; background-color:#ffebe8; border:1px solid #cc0000;\">&nbsp;&nbsp;&nbsp;<b>Error:</b> Invalid Username/Password!</div><br/><br/>";
print "               </div>";
	}
	
} 
else {
 include("loginform.php");
}
mysql_close($conn);
?>