<?php
include("sessionchecker.php");

print "<div style=\"width:835px; height:490px; font-family:Arial; \">";

print "<div style=\"background-color:#c8e2ff; display:block; width:835px; height:15px; padding-top:10px; padding-bottom:10px;\">";
print "<a style=\"padding-left:20px;font-weight:bold; font-size:14px;\">View Existing Users</a>";
print "</div>";

print "<div style=\"background-color:#e3f3ff; display:block; width:835px; height:453px;\">";
print "<div style = \"padding-left:20px; padding-top:10px; padding-right:20px;\">";
print "On this page, you can view,edit and delete all users of your <b>WPInstallation</b> system! Latest Entries are shown First!";

include("viewusers.php");


print "<br/><br/>";
print "</div></div></div>";
?>