<html>
<head>
<script type="text/javascript" src="../js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="../js/paginator.js"></script>
<script type="text/javascript">

$(function () {  
		separator = ' | '; // To separate paginator's items
        paginatorStyle = 1;
        itemsPerPage = 3;
        firstPageSymbol = "<< First Page";
        previousPageSymbol ="< Previous";
        nextPageSymbol ="Next > ";
        lastPageSymbol ="Last Page >>";
		$("#example").pagination();  
	});


</script>

<style type="text/css">
.paginator .inactive
	    {   cursor:default;
			color:#f76120;
			border: solid 1px #ffa615;
			background-color:#fbefdb;
			padding:3px 5px;
			margin:5px;
			text-decoration:none;
		}
		
		.paginator .active
		{
			color:#f76120;
			background-color:#fff;	
			text-decoration:none;
			border: solid 1px #d4d4d4;
			padding:3px 5px;
			margin:5px;
		}
		
		#example
		{
			
			margin: 10px 5px 10px 0;
			padding: 5px 10px;
			width: 795px;
		}
</style>
</head>
<body>
<?php
print "<div id=\"example\">";

include("opendb.php");

$result = mysql_query("SELECT * FROM users ORDER BY ID DESC")  or die(mysql_error());
while ($row = mysql_fetch_array($result)) 
{
          //  ^ must be a single '=' !!!!
 print "<p style=\"background-color:#3887c4;\">
    
        <table style=\"width: 795px; text-align:center;\">
            <tr>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    ID</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["ID"]."</td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Name</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Name"]."</td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Surname</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Surname"]."</td>
            </tr>
            <tr>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Email</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Email"]."</td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Login</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Login"]."</td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Domain</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Domain"]."</td>
            </tr>
            <tr>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Installations</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Installations"]."</td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Used</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Used"]."</td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Saldo</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Saldo"]."</td>
            </tr>
            <tr>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Serial</td>
                <td style=\"background-color: #f8f8f8;\">
                    ".$row["Serial"]."</td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Delete</td>
                <td style=\"background-color: #f8f8f8;\">
                    <a href=\"./delete.php?id=".$row["ID"]."\" target =\"_self\" title=\"Click Here To Delete This User Totally!!\" /><img src=\"../images/wrong.png\" alt=\"\" style=\"border:0px;\" /></a></td>
                <td style=\"background-color: #f0f0f0;  font-weight: bold;\">
                    Edit</td>
                <td style=\"background-color: #f8f8f8;\">
                    <a href=\"./edit.php?id=".$row["ID"]."\" target =\"_self\" title=\"Click Here To Edit This User Info!!\" /><img src=\"../images/right.png\" alt=\"\" style=\"border:0px;\" /></a></td>
            </tr>
        </table>
    
    </p>";
}	
mysql_close($conn);	
print "</div>";
?>
</body>
</html>
