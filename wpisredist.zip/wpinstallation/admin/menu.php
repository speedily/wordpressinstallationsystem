<?php

print "<html>";
print "<head>";
print "<script type=\"text/javascript\" src=\"../js/jquery-1.4.2.min.js\"></script>";
print "<script type=\"text/javascript\" src=\"../js/jquery.pngFix.pack.js\"></script>";
print "<script type=\"text/javascript\">";
print "   $(document).ready(function(){";
print "       $(document).pngFix();";
print "   });";
print "</script>";
print "<style type=\"text/css\">";
print "       img:hover {background-color:#d4dded; border:2px dotted #cdcdcd;}";
print "</style>";
print "</head>";
print "<body>";
print "<div style = \"text-align:left; font-family:Arial; font-style:bold; font-size:12px; text-decoration:none;\" >";
	  
print "<br /><br /><a href=\"add.php\" target=\"show\"><image src=\"../images/user.png\" alt=\"\" style=\"border:0px;\" /></a>";
print "     ";
print "<br /><br /><a href=\"view.php\" target=\"show\"><image src=\"../images/profile.png\" alt=\"\" style=\"border:0px;\" /></a>";
print "     ";
print "<br /><br /><a href=\"settings.php\" target=\"show\"><image src=\"../images/settings.png\" alt=\"\" style=\"border:0px;\" /></a></div>";

print "</html>";
print "</body>";
?>
