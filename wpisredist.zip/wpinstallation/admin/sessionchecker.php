<?php
session_start();
if(!(isset($_SESSION['username'])))
{
	//print "Not set!"; //for unit testing only
	printf("<script>location.href='index.php'</script>");	
}
elseif ((isset($_SESSION['username'])))
{
          $sessiongot = substr($_SESSION['username'],0,5);
          //echo $sessiongot; //for unit testing only
          if ($sessiongot!="Admin")
          {
	       //print "caught you"; //for unit testing only
		   printf("<script>location.href='index.php'</script>");
          }
	
}
// echo $sessiongot; //for unit testing only
// echo "Check User: ".$_SESSION['username']; //for unit testing only

?>