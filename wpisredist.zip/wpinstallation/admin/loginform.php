﻿<?php

print ("<form action=\"$PHP_SELF\" method=\"POST\">");

print "       <br />";
print "       <br />";
print "       <br />";
print "       <br />";
print "       <br />";
print "       <br />";
print "       <br />";
print "	<div style=\"margin-left: 312px; width:250px; height:120px; display:block; background-color:Silver; border-style:outset; \">";
print "       <div style=\"width:100%; background-color:#d4dded; font-weight:bold;\">&nbsp;";
print "Enter Your Login Details!";
print "       </div>";

print "    <table class=\"style1\" border=\"0px;\">";
print "           <tr>";
print "               <td class=\"style2\">";
print "                   Login ID:";
print "               </td>";
print "               <td>";


                print ("<input type=\"text\" name=\"username\" style=\"width:145px;\"><br/>");
				
				
print "                </td>";
print "           </tr>";
print "           <tr>";
print "               <td class=\"style2\">";
print "                   Password:";
print "               </td>";
print "               <td>";

                    print ("<input type=\"password\" name=\"password\" style=\"width:145px;\"><br/>");

print "               </td>";
print "           </tr>";
print "           </table>";
print "               <table class=\"style3\">";
print "                   <tr>";
print "                       <td>";
print "                       </td>";
print "                   </tr>";
print "               </table>";
print "               <table class=\"style1\">";
print "                   <tr>";
print "                       <td class=\"style2\">";
print "                           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
print "                           &nbsp;</td>";
print "                       <td>";

	
						print (" <input type=\"submit\" value=\"Login\" style=\"background-color:#CCCCCC;height:25px;\"></form>");
        
                        
print "                       </td>";
print "                   </tr>";
print "               </table>";
print "               </div>";

      

      
	  
?>