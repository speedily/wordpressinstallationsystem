<?php
print "<div style=\"padding-left:200px; text-align:left; font-family:Arial; font-size:14px;\">";
print "<p>";
print "           Welcome To <b>WPInstallation</b> Administrator&#39;s Control Panel!</p>";
print "   <p>";
print "       YOU CAN NOW:</p>";
print "   <ul>";
print "       <li>Select Any Of The THREE OPTIONS On THE LEFT-HAND SIDE.</li>";
print "       <li>LOGOUT by clicking on &#39;<b>Logout</b>&#39; button on THE TOP-RIGHT-HAND SIDE.</li>";
print "   </ul>";
print "<p>";
print "   For any further queries.. contact <a href=\"http://abhishekjha.net\">Abhishek</a>!</p>";
print "</div>";
?>


