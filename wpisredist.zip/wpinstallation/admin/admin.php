<?php

include("sessionchecker.php");

//if (isset($_POST['Hider'])) 
if ($_POST['view_x'])
{
 //print "Post=".$_POST['Hider']; //for unit testing only
 alogout(); 
}


// logout button calls logout function

//print "<script>\n";
//print "redirectTime = \"1500\";\n";
//print "redirectURL = \"index.php\";\n";
//print "function timedRedirect() \n";
//print "\n";
//print "!--\n";
//print "setTimeout(\"location.href = redirectURL;\",redirectTime);\n";
//print " -->\n";
//print "</script>\n";
//print "\n";

function alogout()
	{
	//echo "reached here..!"; for unit testing only
	if(isset($_SESSION['username']))
	  {
	  unset($_SESSION['username']);
	  session_destroy(); 		
	  header("Location:index.php");
	  //printf("<script>location.href='index.php'</script>");
	  }
	}

print "<form action=\"$PHP_SELF\" method=\"POST\">";
print "<table style=\"width: 980px;height: 50px; background-color:#434343; color:#efefef;\">";
print "               <tr>";
print "                   <td style=\"width:600px;\">";
print " <div style=\"font-size:18px; font-family:Arial; padding-left:10; padding-top:10; padding-right:10px; padding-bottom:10px; \">Welcome To Admin Panel</div>";
print "                   </td>";
print "                   <td>";
//print "<input type=\"hidden\" name=\"Hider\">";
//print "<input type=\"submit\" value=\"Logout\" onclick=\"JavaScript:timedRedirect()\"></form>";
print "<div style=\"float:right;\">";
//print "<input type=\"submit\" value=\"Logout\" style= \"height:35px; width:60px;\" class=\"rush\" >";
print "<input type=\"image\" name=\"view\" src=\"../images/logout.png\"> ";
print "</div>";
print "                       </td>";
print "               </tr>";
print "           </table>";
print "</form>";


	
print "<table style=\"width: 980px;height: 500px; border-style: solid; border-width: 0px;\">";
print "               <tr>";
print "                   <td style=\"width:125px;\">";
print "<iframe src =\"menu.php\" width=\"120px;\" height=\"500px;\" scrolling=\"no\" frameborder=\"0\" >";
print " <p>Your browser does not support iframes.</p>";
print "</iframe>";
print "                        </td>";

print "                   <td style=\"width:855px;\">";
print "<iframe src =\"start.php\" width=\"850px;\" height=\"500px;\" scrolling=\"no\" frameborder=\"0\" name=\"show\" >";
print " <p>Your browser does not support iframes.</p>";
print "</iframe>";
print "                       </td>";
print "               </tr>";
print "           </table>";



?>
