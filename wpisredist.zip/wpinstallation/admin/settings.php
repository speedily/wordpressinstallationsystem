<?php
include("sessionchecker.php");

// if form submit -> update data
if ((isset($_POST['adminusername'])) AND (isset($_POST['adminpassword'])))  
{ 
$adminusername = $_POST['adminusername'];
$adminpassword = $_POST['adminpassword'];

include("opendb.php");

$sql="UPDATE admin SET AdminUsername = '$adminusername',AdminPassword = '$adminpassword'";

    mysql_query($sql,$conn);
  
	//echo "records updated";
	mysql_close($conn);
	
	printf("<script>location.href='sucess.php?type=adminidpasswordchanged'</script>");



}


// get $user, $pass
include("opendb.php");

$result = mysql_query("SELECT AdminUsername,AdminPassword FROM admin") or die(mysql_error());

$row = mysql_fetch_array( $result );
$user = (string)$row['AdminUsername'];
$pass = (string)$row['AdminPassword'];

mysql_close($conn);




//  normal
print "<div style=\"width:835px; height:485px; font-family:Arial;\">";

print "<div style=\"background-color:#c8e2ff; display:block; width:835px; height:15px; padding-top:10px; padding-bottom:10px;\">";
print "<a style=\"padding-left:20px;font-weight:bold; font-size:14px;\">Admin Settings</a>";
print "</div>";

print "<div style=\"background-color:#e3f3ff; display:block; width:835px; height:450px;\">";
print "<div style = \"padding-left:20px; padding-top:10px;\">";
print "On this page, you can view & change the settings of your <b>WPInstallation</b> administrator's user profile!";

print "<br/><br/>";
print ("<form action=\"$PHP_SELF\" method=\"POST\">");
print "<table style=\"width: 100%;\">";
print "       <tr>";
print "           <td style=\"width: 125px;\">";
print "Username:</td>";
print "           <td>";

print       $user;
print "			</td>";
print "       </tr>";
print "       <tr>";
print "           <td style=\"width: 125px;\">";
print "<b>New Username:</b><br/>";
print "           </td>";
print "           <td>";
print "               <input type=\"text\" name=\"adminusername\" style=\"width: 150px;\" /></td>";
print "       </tr>";
print "       <tr>";
print "           <td style=\"width: 125px;\">";
print "               &nbsp;</td>";
print "           <td>";
print "               &nbsp;</td>";
print "       </tr>";
print "       <tr>";
print "           <td style=\"width: 125px;\">";
print "Password:";
print "           </td>";
print "           <td>";
print       $pass;
print "			</td>";
print "       </tr>";
print "       <tr>";
print "           <td style=\"width: 125px;\">";
print "<b>New Password:</b><br/>";
print "           </td>";
print "           <td>";
print "               <input type=\"password\" name=\"adminpassword\" style=\"width: 150px;\" /></td>";
print "       </tr>";
print "       <tr>";
print "           <td style=\"width: 125px;\">";
print "               &nbsp;</td>";
print "           <td>";
print (" <input type=\"submit\" value=\"Submit Changes\" style=\"background-color:#CCCCCC;height:25px;width: 150px;\">");
print "               </td>";
print "       </tr>";
print "   </table>";
print "</form>";
print "<br/><br/> <b>Note:</b> All changes are visible instantly. So do not change your password in public places! If you want to change passwords without viewing existing password here, contact <a href=\"http://abhishekjha.net\">Abhishek</a> to change the program code.";
print "</div></div></div>";
?>