<?php
$id=$_GET['id'];  
$type=$_GET['type'];  

include("sessionchecker.php");

print "<div style=\"width:835px; height:490px; font-family:Arial; \">";

print "<div style=\"background-color:#c8e2ff; display:block; width:835px; height:15px; padding-top:10px; padding-bottom:10px;\">";
print "<a style=\"padding-left:20px;font-weight:bold; font-size:14px;\">Success</a>";
print "</div>";

print "<div style=\"background-color:#e3f3ff; display:block; width:835px; height:453px;\">";
print "<div style = \"padding-left:20px; padding-top:10px; padding-right:20px;\">";
if (!empty($id) && !empty($type))
{
if($type=="useradded")
{
print"<div style=\"display:block; background-color:#edffe8; border:1px solid #0ecc00; margin-left: 152px; margin-top:100px; width:450px; text-align:center;\">
	  <img src=\"../images/right.png\"><big>Congratulations!!</big><br/> User with <b>ID</b>:<b>".$id."</b> has been added sucessfully.
	  </div>";
	//add more users?
print"<br/><br/><br/><br/><br/><br/>";
print"<div style=\"display:block; margin-left: 162px; padding-top:5px; width:430px; height:90px; text-align:center; background-color:#ffffff; border-style:outset; \">";
print "<table style=\"width:450px;\">
        <tr>
            <td>
                <img src=\"../images/faq.png\" /></td>
            <td>
                <big>Would you like to add more users now?</big></td>
        </tr>
    </table>
	  ";
print " <a href=\"add.php\" style=\"border:1px solid #cccccc; text-decoration:none; background-color:#ffffff;\" ><b>&nbsp;YES&nbsp;</b></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href=\"start.php\" style=\"border:1px solid #cccccc; text-decoration:none; background-color:#ffffff;\" ><b>&nbsp;NO&nbsp;</b></a>";
print "</div>";	
}
elseif($type=="userdeleted")
{
print"<div style=\"display:block; background-color:#edffe8; border:1px solid #0ecc00; margin-left: 152px; margin-top:100px; width:450px; text-align:center;\">
	  <img src=\"../images/right.png\"><big>Congratulations!!</big><br/> User with <b>ID</b>:<b>".$id."</b> has been deleted sucessfully.
	  </div>";
	//delete more users?
print"<br/><br/><br/><br/><br/><br/>";
print"<div style=\"display:block; margin-left: 162px; padding-top:5px; width:430px; height:90px; text-align:center; background-color:#ffffff; border-style:outset; \">";
print "<table style=\"width:450px;\">
        <tr>
            <td>
                <img src=\"../images/faq.png\" /></td>
            <td>
                <big>Would you like to delete more users?</big></td>
        </tr>
    </table>
	  ";
print " <a href=\"view.php\" style=\"border:1px solid #cccccc; text-decoration:none; background-color:#ffffff;\" ><b>&nbsp;YES&nbsp;</b></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href=\"start.php\" style=\"border:1px solid #cccccc; text-decoration:none; background-color:#ffffff;\" ><b>&nbsp;NO&nbsp;</b></a>";
print "</div>";
}
elseif($type=="useredited")
{
print"<div style=\"display:block; background-color:#edffe8; border:1px solid #0ecc00; margin-left: 152px; margin-top:100px; width:450px; text-align:center;\">
	  <img src=\"../images/right.png\"><big>Congratulations!!</big><br/>Information of User with <b>ID</b>:<b>".$id."</b> has been updated sucessfully.
	  </div>";
	//edit more user information?
print"<br/><br/><br/><br/><br/><br/>";
print"<div style=\"display:block; margin-left: 162px; padding-top:5px; width:430px; height:90px; text-align:center; background-color:#ffffff; border-style:outset; \">";
print "<table style=\"width:450px;\">
        <tr>
            <td>
                <img src=\"../images/faq.png\" /></td>
            <td>
                <big>Would you like to edit more user information?</big></td>
        </tr>
    </table>
	  ";
print " <a href=\"view.php\" style=\"border:1px solid #cccccc; text-decoration:none; background-color:#ffffff;\" ><b>&nbsp;YES&nbsp;</b></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href=\"start.php\" style=\"border:1px solid #cccccc; text-decoration:none; background-color:#ffffff;\" ><b>&nbsp;NO&nbsp;</b></a>";
print "</div>";
}
}
elseif(!empty($type) && $type=="adminidpasswordchanged")
{
print"<div style=\"display:block; background-color:#edffe8; border:1px solid #0ecc00; margin-left: 152px; margin-top:100px; width:450px; text-align:center;\">
	  <img src=\"../images/right.png\"><big>Congratulations!!</big><br/> Admin's <b>User ID</b> &amp; <b>Password</b> has been changed sucessfully.
	  </div>";
	//change id/pass once more?
print"<br/><br/><br/><br/><br/><br/>";
print"<div style=\"display:block; margin-left: 162px; padding-top:5px; width:430px; height:90px; text-align:center; background-color:#ffffff; border-style:outset;\">";
print "<table style=\"width:450px;\">
        <tr>
            <td>
                <img src=\"../images/faq.png\" /></td>
            <td>
                <big>Would you like to change id/pass once more?</big></td>
        </tr>
    </table>";
print " <a href=\"settings.php\" style=\"border:1px solid #cccccc; text-decoration:none; background-color:#ffffff;\" ><b>&nbsp;YES&nbsp;</b></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href=\"start.php\" style=\"border:1px solid #cccccc; text-decoration:none; background-color:#ffffff;\" ><b>&nbsp;NO&nbsp;</b></a>";
print "</div>";
}
print "<br/><br/>";
print "</div></div></div>";
?>