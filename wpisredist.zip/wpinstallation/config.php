<?php
// This is our database configuration file
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = 'root';
$dbname = 'wpinstallation';
?>