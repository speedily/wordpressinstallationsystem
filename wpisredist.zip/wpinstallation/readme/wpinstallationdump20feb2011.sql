-- phpMyAdmin SQL Dump
-- version 2.9.1.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Feb 20, 2011 at 07:37 AM
-- Server version: 5.0.27
-- PHP Version: 4.4.4
-- 
-- Database: `wpinstallation`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `admin`
-- 

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `AdminPassword` varchar(12) NOT NULL,
  `AdminUsername` varchar(12) NOT NULL,
  KEY `AdminPassword` (`AdminPassword`),
  KEY `AdminUsername` (`AdminUsername`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `admin`
-- 

INSERT INTO `admin` VALUES ('cd', 'ab');

-- --------------------------------------------------------

-- 
-- Table structure for table `plugins`
-- 

DROP TABLE IF EXISTS `plugins`;
CREATE TABLE IF NOT EXISTS `plugins` (
  `name` varchar(60) NOT NULL,
  `ref` varchar(60) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `plugins`
-- 

INSERT INTO `plugins` VALUES ('Q and A - FAQ Plugin', 'q-and-a.0.2.1.zip');
INSERT INTO `plugins` VALUES ('PS Auto Sitemap', 'ps-auto-sitemap.zip');
INSERT INTO `plugins` VALUES ('Page Links To', 'page-links-to.2.4.zip');
INSERT INTO `plugins` VALUES ('NextGEN Gallery', 'nextgen-gallery.zip');
INSERT INTO `plugins` VALUES ('My Calendar', 'my-calendar.zip');
INSERT INTO `plugins` VALUES ('Login Configurator', 'login-configurator.zip');
INSERT INTO `plugins` VALUES ('Google XML Sitemaps', 'google-sitemap-generator.3.2.4.zip');
INSERT INTO `plugins` VALUES ('Google Analyticator', 'google-analyticator.6.1.1.zip');
INSERT INTO `plugins` VALUES ('Front-end Editor', 'front-end-editor.1.9.2.1.zip');
INSERT INTO `plugins` VALUES ('Flexi Quote Rotator', 'flexi-quote-rotator.zip');
INSERT INTO `plugins` VALUES ('Find Me Else Where', 'find-me-elsewhere.zip');
INSERT INTO `plugins` VALUES ('Silencesoft RSS Reader', 'external-rss-reader.zip');
INSERT INTO `plugins` VALUES ('Cute Profiles', 'cute-profiles.1.0.1.zip');
INSERT INTO `plugins` VALUES ('CMS Dashboard', 'content-management-system-dashboard.zip');
INSERT INTO `plugins` VALUES ('CMS Tree Page View', 'cms-tree-page-view.0.7.12.zip');
INSERT INTO `plugins` VALUES ('Capability Manager', 'capsman.zip');
INSERT INTO `plugins` VALUES ('Adminimize', 'adminimize.1.7.12.zip');
INSERT INTO `plugins` VALUES ('WPML Multilingual CMS', 'sitepress-multilingual-cms.2.0.4.zip');
INSERT INTO `plugins` VALUES ('TinyMCE Advanced', 'tinymce-advanced.3.2.7.zip');
INSERT INTO `plugins` VALUES ('Wordpress Forms', 'wordpress-forms.0.2.7.zip');
INSERT INTO `plugins` VALUES ('WP Maintenance Mode', 'wp-maintenance-mode.1.6.6.zip');
INSERT INTO `plugins` VALUES ('WP Symposium', 'wp-symposium.zip');
INSERT INTO `plugins` VALUES ('Tickets', 'zingiri-tickets.1.0.6.zip');
INSERT INTO `plugins` VALUES ('Zingiri Web Shop', 'zingiri-web-shop.1.6.9.zip');

-- --------------------------------------------------------

-- 
-- Table structure for table `themes`
-- 

DROP TABLE IF EXISTS `themes`;
CREATE TABLE IF NOT EXISTS `themes` (
  `name` varchar(60) NOT NULL,
  `ref` varchar(60) NOT NULL,
  `zip` varchar(60) NOT NULL,
  `styledotcssthemename` varchar(60) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `themes`
-- 

INSERT INTO `themes` VALUES ('Business Achievements','business-achievements-bue062-2.21', 'business_achievements_bue062.zip','business achievements bue062');
INSERT INTO `themes` VALUES ('Business Social Handshake','business-social-handshake-bue020-2.21', 'business_social_handshake_bue020.zip','business social handshake bue020');
INSERT INTO `themes` VALUES ('Charcoal','Charcoal-1.3', 'charcoal.zip','Charcoal');
INSERT INTO `themes` VALUES ('eDegree', 'eDegree-1.1','edegree.zip','eDegree');
INSERT INTO `themes` VALUES ('Island Two Palm Trees','island-two-palm-trees-lae048-2.21' ,'island_two_palm_trees_lae048.zip','island two palm trees lae048');
INSERT INTO `themes` VALUES ('Wordpress Shopping Cart','WSC6-1.0.5' ,'wsc6.zip','WSC6');

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(4) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Surname` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Login` varchar(12) NOT NULL,
  `Domain` varchar(60) NOT NULL,
  `Installations` int(3) NOT NULL,
  `Used` int(3) NOT NULL,
  `Saldo` int(3) NOT NULL,
  `Serial` varchar(20) NOT NULL,
  `pluginsallowed` varchar(1465) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` VALUES (4, 'Ankita', 'Jha', 'ankita@123.com', 'anki', 'http://yahoo.com', 5, 0, 5, '1D1M6ERVI91IVTZKQ2LJ', '@Q and A - FAQ Plugin@Front-end Editor@Adminimize');
INSERT INTO `users` VALUES (2, 'Dia', 'Ask', 'abc@def.com', 'mogger', 'http://ftpbox.net', 9, 4, 5, 'Yahoo', '');
INSERT INTO `users` VALUES (3, 'Abhishek', 'Jha', 'hello@abhishekjha.net', 'blah', 'http://abhishekjha.net', 4, 0, 4, 'IEQAR16GG33KWXN11D6X', '$@Q and A - FAQ Plugin@Login Configurator@Google XML Sitemaps@Google Analyticator@Silencesoft RSS Reader@Cute Profiles@CMS Dashboard@CMS Tree Page View@Adminimize@TinyMCE Advanced@Wordpress Forms@WP Symposium@Zingiri Web Shop#');
INSERT INTO `users` VALUES (1, 'Avi', 'Jha', '123@456.com', 'logger', 'http://test.com', 3, 3, 0, 'Blah', '');
INSERT INTO `users` VALUES (5, 'aa', 'aa', 'aa', 'aa', 'aa', 5, 0, 5, '2QJAW8FKE3CMLKS8T3F8', '@Q and A - FAQ Plugin@NextGEN Gallery');
INSERT INTO `users` VALUES (6, 'Saro', 'Beta', 'sarita@123.com', 'sar', 'http://google.com', 45, 5, 40, '5NSZC9NLG14EJCGDY3LA', '@Page Links To@NextGEN Gallery@Silencesoft RSS Reader');
