<?php
session_start();
if(!(isset($_SESSION['userserial'])))
{
	//print "Not set!"; //for unit testing only
	printf("<script>location.href='index.php'</script>");	
}
elseif ((isset($_SESSION['username'])))
{
          //$sessiongot = substr($_SESSION['username'],0,5);
		  $sessiongot = $_SESSION['userserial'];
          //echo $sessiongot; //for unit testing only
          if ($sessiongot==NULL || $sessiongot=="" || $sessiongot==" ")
          {
	       //print "caught you"; //for unit testing only
		   printf("<script>location.href='index.php'</script>");
          }
	
}
//echo $sessiongot; //for unit testing only
//echo "Check User: ".$_SESSION['userserial']; //for unit testing only

?>