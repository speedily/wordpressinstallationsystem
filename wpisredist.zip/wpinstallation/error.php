<?php
include("sessionchecker.php");

if ((isset($_POST['Submit'])))
{
//echo "reached here..!"; //for unit testing only
      if (isset($_SESSION['userserial']))
	  {
	  unset($_SESSION['userserial']);
	  session_destroy(); 		
	  header("Location:index.php");
//	  echo "reached redirect..!"; //for unit testing only
	  //printf("<script>location.href='index.php'</script>");
	  }
}

//Get value of 
$ex = "<b>ERROR:</b>";
//$x =  "WPISCE on target Installation Directory.Remove all files on target Installation Directory or Try using a different target Installation Directory for this to work.";
$x = $_SESSION['error'];

//Show the error
// Show.failureMessage(with ReasonsOfFailure toshow tothe wpinstaller provider i.e,fabio);
    $centerscreenerrorboxstart= "<div style =\"margin-left:250px;margin-top:100px; display:block; border:1px solid #ccc; width:500px;\"><table style=\"display:block; background-color:#efefef; width:500px;\"><tr><td><img src=\"./images/error.png\" /></td><td><big>An Error Occurred!</big></td></tr></table><div style=\"padding-left:10px; padding-right:10px;\">";
	print "<form name=\"sports\" action=\"$PHP_SELF\" method=\"POST\">";
    print $centerscreenerrorboxstart;
    print "<p>".$ex.$x."</p>";
    print "<div style=\"display:block; background-color:LightYellow;\"><div style=\"padding-left:10px; padding-right:10px;\">";
	print "<b>HINT:</b>";
	print "<ol>";
	print "<li>Use the \"<b>Yes</b>\" button below to go back and \"<b>Change The Entered Values</b>\" and \"<b>Install</b>\" once more to see if it works! or \"<b>Fix The Issue</b>\" as mentioned in Error Message above.</li>";
	print "<li>You may also \"<b>Note Down</b>\" the Error Message above to help yourself remember better about this.</li>";
    print "<li>Do Not Press the \"<b>Back Button</b>\" of your browser, Only use the buttons below, Else the Problem Might Get Worse.</li>";
	print "</ol>";
//	print "<div style=\"text-align:center;\">";
	print "<input type=\"button\" onclick=\"window.location='./ftpinput.php';\" value=\"Yes, I'll Go Back and Install!\">";
	print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	print "<input class=\"button\" name=\"Submit\" type=\"submit\" value=\"No, I'll Exit!\"/>";
//	print "</div>";
	print "</div></div><br/>";
	$centerscreenerrorboxend = "</div></div>";
    print $centerscreenerrorboxend;
	print "</form>";
?>