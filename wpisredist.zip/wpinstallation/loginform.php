﻿<?php

print ("<form action=\"$PHP_SELF\" method=\"POST\">");

print "       <br />";
print "       <br />";
print "       <br />";
print "       <br />";
print "       <br />";
print "       <br />";
print "       <br />";
print "<div style=\"margin-left: 337px; width:310px; height:220px; display:block; border:1px solid #efefef;\">";
print "<img src= \"./images/wpis.png\" style=\"margin-left:10px;margin-top:10px;\" ><br/><br/>";
print "       <div style=\"margin-left:60px; width:100%; font-weight:bold;\">&nbsp;";
print "Enter Your Activation Details!";
print "       </div>";

print "    <table style=\"margin-left:60px;\" border=\"0px;\">";
print "           <tr>";
print "               <td class=\"style2\">";
print "                   Login ID:";
print "               </td>";
print "               <td>";


                print ("<input type=\"text\" name=\"login\" style=\"width:145px;\"><br/>");
				
				
print "                </td>";
print "           </tr>";
print "           <tr>";
print "               <td class=\"style2\">";
print "                   Activation:";
print "               </td>";
print "               <td>";

                    print ("<input type=\"text\" name=\"serial\" style=\"width:145px;\"><br/>");

print "               </td>";
print "           </tr>";
print "           </table>";
print "               <table class=\"style3\">";
print "                   <tr>";
print "                       <td>";
print "                       </td>";
print "                   </tr>";
print "               </table>";
print "               <table class=\"style1\">";
print "                   <tr>";
print "                       <td class=\"style2\">";
print "                           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
print "                           &nbsp;</td>";
print "                       <td>";

	
						print (" <input type=\"submit\" value=\"Login\" style=\"background-color:#CCCCCC;height:25px; margin-left:50px;\"></form>");
        
                        
print "                       </td>";
print "                   </tr>";
print "               </table>";
print "               </div>";

      

      
	  
?>