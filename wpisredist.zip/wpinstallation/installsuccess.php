<?php 
include("sessionchecker.php");

		 //$_SESSION['site_url']="http://ftpbox.net/"; for unit test only
		 print"<div style=\"display:block; background-color:#edffe8; border:1px solid #0ecc00; margin-left: 180px; margin-top:25px; width:650px; height:385px;\">
	     <div style=\"text-align:center;\"><img src=\"./images/congratulations.png\"><br/> <span style=\"border-bottom:1px dashed #0ecc00;\">Your wordpress website has been sucessfully installed!</span>
		 <p>Your <b>ADMIN LOGIN ID</b> is: <span style=\"background-color:yellow;border:1px dashed #ccc;\"><b>admin</b></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Your <b>ADMIN LOGIN PASSWORD</b> is: <span style=\"display:inline;background-color:yellow;border:1px dashed #ccc;\"><b>admin</b></span></p></div>
		 <div style=\"padding-left:10px;padding-right:5px;\"><p>Please note down your ADMIN LOGIN ID and PASSWORD. It is very important in the process. You can now goto <a href=\"".$_SESSION['site_url']." \">".$_SESSION['site_url']."</a> and see your newly installed wordpress site with the theme and many plugins of your choice that we have added for you.<br/>
		 <br/><b>Most Importantly</b>:<br/>
		 1.You can login into your site administration control panel at <a href=\"".$_SESSION['site_url']."wp-login.php\">".$_SESSION['site_url']."wp-login.php</a> using the ADMIN ID and PASSWORD we mentioned above to modify your site, ID & PASS.<br/>
		 2.You need to chmod INSTALL directory:<b>".$_SESSION['ftp_InstallDirectory']."</b> back to 0755 or lower access permission for increased/higher security of this folder.<br/>
		 Furthermore, If you loose your <b>ADMIN ID/PASSWORD</b>, then contact me at my e-mail below.</p>
		 <p>Best Regards, Fabio - Fabio [at] Gefuso.com</p>
	     </div>";
    	 //add more users?
         print"<br/><br/>
         <div style=\"display:block; margin-left: 45px; padding-top:5px; width:550px; height:90px; text-align:center; background-color:#ffffff; border-style:outset; \">
         <table style=\"width:100%;\">
         <tr>
            <td>
                <img src=\"./images/info.png\" /></td>
            <td>";
  //       print "<big>Would you like to Perform Another Wordpress Installation now?</big></td>";
         print "<big>Press the button below to Exit!</big>";
		 print "<br/><b>Note:</b> Only use the option button we provide below to avoid any kind of errors.
			</td>
         </tr>
         </table>";
		 // Show 'Install Once More' Button
		 // onInstallOnceMore; // if (UserSaldo>=1) {goto ftpinput.php for the same user} else { print "You are out of balance. You cannot install anymore. Please Increase Your balance to be able Install Again. Now you can only use 'Exit' button above."; }
//         print "<a href=\"add.php\" style=\"border:1px solid #cccccc; text-decoration:none; background-color:#ffffff;\" ><b>&nbsp;YES&nbsp;</b></a>
//		 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; 
		 //Show 'Exit' Button,
		 // onExit; // logout from session and redirect to homepage
//		 print "<a href=\"start.php\" style=\"border:1px solid #cccccc; text-decoration:none; background-color:#ffffff;\" ><b>&nbsp;NO&nbsp;</b></a>
   
         // Show exit button
         // onExit; // logout from session 
         if(isset($_SESSION['userserial']))
	     {
	     unset($_SESSION['userserial']);
	     session_destroy(); 		
	     }
	     print "<div style=\"text-align:center;\"><input type=\"button\" onclick=\"window.location='./index.php';\" value=\"OK.. Exit Now!\"></div><br/>
		 </div>";
?>