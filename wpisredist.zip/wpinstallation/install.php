<?php
include("sessionchecker.php");

//Step1.Get Selection and Install Info Data
  //show Selected USER info
    
	//show user serial
	$serial=$_SESSION['userserial'];
	//$serial ="1D1M6ERVI91IVTZKQ2LJ";//for unit testing only
include("opendb.php"); 
$result = mysql_query("SELECT * FROM users WHERE Serial='".$serial."'")  or die(mysql_error());
$row = mysql_fetch_array($result);
$id = $row["ID"];
$name= $row["Name"];
$domain= $row["Domain"];
$saldo = $row["Saldo"];
$used = $row["Used"];
$user_email = $row["Email"];
mysql_close($conn); 
    //show user id
	//$id
	//show user name
	//$name
	//show user saldo
	//$saldo
  //show FTP info
    //Domain Name:
	//$domain
	//FTP Username:
	$ftp_username=$_SESSION['ftp_username'];
	//FTP Password:
	$ftp_password=$_SESSION['ftp_password'];
	//FTP Hostname:
	$ftp_hostname=$_SESSION['ftp_hostname'];
	//Installation Directory:
	$ftp_InstallDirectory=$_SESSION['ftp_InstallDirectory'];
  //show MYSQL info
    //Database Name:
	//$_SESSION['mysql_dbname']
	//User Name:
	//$_SESSION['mysql_username']
	//Password:
	//$_SESSION['mysql_password']
	//Database Host:
	//$_SESSION['mysql_dbhost']
	//Table Prefix:
	//$_SESSION['mysql_tableprefix']
  //show SITE info
    //Site Title:
	//$_SESSION['site_title']
	//Site URL:
	//$_SESSION['site_url']
	   //we dont need to set user pass
       //$_SESSION['site_username'] = $_POST['site_username'];
       //$_SESSION['site_password'] = $_POST['site_password'];
	//Your E-mail:
	//$_SESSION['site_email']
	//Allow my site to appear in search engines like Google and Technorati:'Yes' || 'No'
	//$_SESSION['site_visibletosearchengines']
  //show Selected THEME info
    //its no issue if no theme is selected, we set $themetype=none (where default is used) else $themetype=selected
	//$_SESSION['selected_theme']
  //show Selected PLUGINS info
    //its no issue if no plugins are selected, we set $plugintype=none (where default is used) else $plugintype=selected
	//$_SESSION['selected_plugins']


//Work on Installer Result
function errorpage($x) //elseif(installerResult="fail" || errors in any part)
{
    $_SESSION['error'] = $x;
    printf("<script>location.href='error.php'</script>");
	//This has already been taken care of by function errorpage(), so no need of below, but it could be used to add functions to errorpage
	  // Delete.allMysqltables(with (this.tablename.Prefix)).via_ftp(); // no need files overwritten
	  // Delete.allfilesandfolders().via_ftp(); // no need files overwritten
	  // //do not do anything in user records
}

//print installer
print "<div style=\"margin-left: 237px; width:510px; height:190px; display:block; border:1px solid #efefef; margin-top:200px;\">";
print "<div style= \"text-align:center; padding-top:7px;\">
<a><big><big>Installing...</big></big></a>
<p>
<img src=\"./images/loading6.gif\"/>
</p>
<br/>
<div style=\"text-align:left; padding-left:10px; padding-right:5px; display:block; background-color:LightYellow;\">
<b>Note:</b> Doing any other activity on your pc/browser during the install can fail the installer system. Please give us 10 seconds of your time for installation to finish.
</div>
</div>";
print "</div>";
	
//Step2.Start Tests Before Installation // Add : Before Step On Print {jsTextPrint($StepNumber+":"+$StepName);}, Add : After Step On else {jsProgressBar(progressvalue +=1);}
  //Check if user has sufficient balance to perform install. 
  //Because the users after a sucessfull install might hijack session by pressing "Back" button on browser 
  //and try to install more than available balance leading to Negative(-) Saldo Balance 
  //and Improperly Incremented NoOfInstalls Done By This User balance, they will be stopped with this.
  $UserSaldo=$saldo;
   if ($UserSaldo<=0) 
   { 
    $centerscreenerrorboxstart= "<div style =\"margin-left:250px;margin-top:180px; display:block; border:1px solid #ccc; width:500px;\"><table style=\"display:block; background-color:#efefef;\"><tr><td><img src=\"./images/error.png\" /></td><td><big>An Error Occurred!</big></td></tr></table><div style=\"padding-left:10px; padding-right:10px;\">";
    print $centerscreenerrorboxstart;
    print "<b>Error:</b>You are out of balance. You cannot install anymore. Please Increase Your balance to be able Install Again. Now you can only exit."; 
  // Show exit button
  // onExit; // logout from session 
     if(isset($_SESSION['userserial']))
	  {
	  unset($_SESSION['userserial']);
	  session_destroy(); 		
	  }
	print "<div style=\"text-align:center;\"><input type=\"button\" onclick=\"window.location='./index.php';\" value=\"OK\"></div><br/>";
    
	$centerscreenerrorboxend = "</div></div>";
    print $centerscreenerrorboxend;
  // and redirect to homepage
  }
  else if($UserSaldo>0)
  {

    
	//Carry On..

  //Allowed Domain usage on installation target test
    $alloweddomain = substr($domain,7);
	$ftphostname= $ftp_hostname;
	$startsearch = strlen($ftphostname)-strlen($alloweddomain);
	
    //1.Test if(isfound($alloweddomain).in($ftphostname)!= true){ $installerResult="fail"; errorpage("FTP Hostname value should have Allowed Domain value in it."); }
      if (substr($ftphostname,$startsearch) != $alloweddomain) { $installerResult="fail"; errorpage("FTP Hostname value should have Allowed Domain value in it."); exit(); }
	  //ini_set("display_errors", false); // set warnings and errors off since we will trap and show our meaningful error messages!
	  
  //Ftp Config test
    //2.Test if(FTPconnection.works!=true){ $installerResult="fail"; errorpage("FTP Connection does not work. Try changing FTP Details values."); }
             $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
             $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
             // check connection
             if ((!$conn_id) || (!$login_result)) { // close the FTP stream
            ftp_close($conn_id); $installerResult="fail"; errorpage("FTP Connection does not work. Try changing FTP Details values."); exit(); }
    //3.Test if(filecreation.works!= true){ $installerResult="fail"; errorpage("FTP A/c does not allow new File Creation. Try changing FTP A/c settings or FTP Details values."); }
	         $file = './upload/wp_config.php'; $remote_file = 'wp_config.php';
             $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
             $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
             // upload a file
             if (!ftp_put($conn_id, $ftp_InstallDirectory.$remote_file, $file, FTP_BINARY)) {       // close the connection
             ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/c does not allow new File Creation. Try changing FTP A/c settings or FTP Details values."); exit(); }
    //4.Test if(filechmod.works!=true){ $installerResult="fail"; errorpage("FTP A/c does not allow File Permission/CHMOD Changes. Try changing FTP A/c settings or FTP Details values."); }
	         $file = 'wp_config.php'; 
             $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
             $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
             // try to chmod $file to 777
			 $mode = 777; $np = '0'.$mode;// Turn the mode into a string // Now run chmod with the eval'd string parsed as an integer.
             if (!ftp_chmod($conn_id, eval("return({$np});"), $ftp_InstallDirectory.$file)) {// close the connection
             ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/c does not allow File Permission/CHMOD Changes. Try changing FTP A/c settings or FTP Details values."); exit(); }
    //5.Test if(filedeletion.works!=true){ $installerResult="fail"; errorpage("FTP A/c does not allow File Deletion. Try changing FTP A/c settings or FTP Details values."); }
	         $file = 'wp_config.php'; 
             $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
             $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
             if (!ftp_delete($conn_id, $ftp_InstallDirectory.$file)) { 
			 ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/c does not allow File Deletion. Try changing FTP A/c settings or FTP Details values."); exit(); }
			 
 //Mysql & ZipClass Config test
    
	//6.create a connection file with connection details	 
			 $junk = './junk/'.$id.'_mysql.php';
			 $fp=fopen($junk, 'w'); //Write to file	
             $blah= '<?php // This is our database configuration file
             $dbhost = "'.$_SESSION['mysql_dbhost'].'"; $dbuser = "'.$_SESSION['mysql_username'].'";$dbpass = "'.$_SESSION['mysql_password'].'"; $dbname = "'.$_SESSION['mysql_dbname'].'";
			 //turn off warnings //ini_set("display_errors", false); //error_reporting(0); //we can also use @ to supress errors along with the 2 things
             $conn = @mysql_connect($dbhost, $dbuser, $dbpass);
             $conn2 = @mysql_select_db($dbname);
			 
			 //check zipclass
             if(!class_exists(\'ZipArchive\'))
			 { die ("ZipArchive is not enabled");}
			 
			 //check writable permission for zip  in ./ current folder
			 if(!is_writable(\'./\'))
	         { die ("Current folder is not writable for zip");}
                 
			 //connect to mysql
             if ((!$conn) || (!$conn2)) { die ("MYSQL_Connect:NO");} 
			 
			 //create table
			  $sql = "CREATE TABLE mytable (col1 INT, col2 VARCHAR(10))";
              if (!mysql_query($sql, $conn)) { die("MYSQL_CreateTable:NO");}
			 
			 //insert records
			  $sql="INSERT INTO mytable (col1, col2)
                    VALUES (\'1\', \'value\')";
			  if (!mysql_query($sql, $conn)) { die("MYSQL_Insert:NO");}
			 
			 //update records
			  $sql = "UPDATE mytable SET col2 = \'newvalue\' WHERE col1 = \'1\'";
              if (!mysql_query($sql, $conn)) { die("MYSQL_Update:NO");}
			 
			 //drop rows and //drop tables is not required if so far works
			  $sql = "DELETE FROM mytable WHERE col1=\'1\'";
			  if (!mysql_query($sql, $conn)) { die("MYSQL_Delete:NO");}
			 
			 //drop tables
			  $sql = "DROP TABLE mytable";
              if (!mysql_query($sql, $conn)) { die("MYSQL_DropTable:NO");}
			 
			 //in case of no error
			  echo "abhishekjha.net";
			 
			 //close connection
              mysql_close($conn); ?>';
			 fputs($fp, $blah);
             fclose($fp); 
	//7.ftp the file      
	         $mysqlpath="junk/".$id.'_mysql.php'; $mysql = 'mysqlcontester.php';
			 //load em
			 $file = $mysqlpath; $remote_file = $mysql;
			 //lines 176,177,178 show warnings
             $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
             $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
             if (!ftp_put($conn_id, $ftp_InstallDirectory.$remote_file, $file, FTP_BINARY)) {       // close the connection
             ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/c does not allow new File Creation. Try changing FTP A/c settings or FTP Details values."); exit(); }
	//8.run the file
			 //$site_url = "http://ftpbox.net/wordpress/"; for unit testing only
			 $site_url= $_SESSION['site_url'];
			 $content = file_get_contents($site_url.$remote_file);
             if (!$content) { $installerResult="fail"; errorpage("Site URL location is incorrect. Try changing Site URL settings values."); exit(); } 
             else { 
	//9.fetch file content
	//10.Test if ZipArchive class exists or not
	         if ($content==trim("ZipArchive is not enabled")) {$installerResult="fail"; errorpage("The PHP 5.2 ZipArchive Class support is not enabled on target server. Try to re-compile PHP 5.2 with ZIP enabled option."); exit(); }
	//11.Test if Current folder is writable or not
			 if ($content==trim("Current folder is not writable for zip")) {$installerResult="fail"; errorpage("The Current Installation folder:<b>".$ftp_InstallDirectory."</b> is not writable. It needs to be writable for extracting zip. Try to <b>chmod</b> the current installation folder <b>".$ftp_InstallDirectory."</b> to <b>0777</b> in permission settings."); exit(); } 
	//12.Test if(MYSQLconnection.works!=true){ $installerResult="fail"; errorpage("MYSQL Connection does not work. Try changing MYSQL Details values."); }
			 if ($content==trim("MYSQL_Connect:NO")) {$installerResult="fail"; errorpage("MySQL connection failed because settings are incorrect. Try changing MySQL settings values."); exit(); }
//Test if(MYSQL.isAbleto(create tables, insert records, update records, drop rows)!=true){ $installerResult="fail"; errorpage("MYSQL A/c does not allow to one out of 1.Create Tables, 2.Insert records, 3.Update records, 4. Drop rows, 5.Drop tables. Try changing MYSQL user a/c permissions or MYSQL Details values."); }		 
	//13.Create table
	         //echo "ended before mysql table create"; //exit(); //works fine
             if ($content==trim("MYSQL_CreateTable:NO")) { $installerResult="fail"; errorpage("MYSQL A/c does not allow to Create Tables. Try changing MYSQL user a/c permissions or MYSQL Details values."); exit(); }		 
	//14.Insert
             if ($content==trim("MYSQL_Insert:NO")) { $installerResult="fail"; errorpage("MYSQL A/c does not allow to Insert records. Try changing MYSQL user a/c permissions or MYSQL Details values."); exit(); }
	//15.Update
             if ($content==trim("MYSQL_Update:NO")) { $installerResult="fail"; errorpage("MYSQL A/c does not allow to Update records. Try changing MYSQL user a/c permissions or MYSQL Details values."); exit(); }		 
	//16.Drop rows
             if ($content==trim("MYSQL_Delete:NO")) { $installerResult="fail"; errorpage("MYSQL A/c does not allow to Delete rows. Try changing MYSQL user a/c permissions or MYSQL Details values."); exit(); }		 
	//17.Drop table
			 if ($content==trim("MYSQL_DropTable:NO")) { $installerResult="fail"; errorpage("MYSQL A/c does not allow to Delete Table. Try changing MYSQL user a/c permissions or MYSQL Details values."); exit(); }		 
			 } // end of else
			 //echo "ended after mysql checks";	 //exit(); //works fine
	//18.delete the junk file from my disk
			 $deljunk=unlink($junk);
			 if (!$deljunk) { $installerResult="fail"; errorpage("Site SQL Junk cannot be deleted. Try to contact site admin."); exit(); }
	//19.delete the junk file from ftp
             $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
             $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
			 $delfileviaftp= $ftp_InstallDirectory.$remote_file;
			 //echo "Mysql Contester 2 delete:".$delfileviaftp; exit(); for unit testing only ;)
			 if (!ftp_delete($conn_id, $delfileviaftp)) {ftp_close($conn_id); $installerResult="fail"; errorpage("MySQL status checker file deletion error. Try changing FTP permissions on your server folder to 777 for installation process to work."); exit(); }
			  
//this situation will not come as we will import table on db with error handling during import and all files will be ftp to server in overwrite mode
  //Wordpressinstallation existence test
    //x.Test if(exists(wpinstallation.ontargetdirectory)==true){ $installerResult="fail"; errorpage("A Wordpress installation already exists on the target Installation Directory.Remove all files on target Installation Directory or Try using a different target Installation Directory for this to work."); }
    //x.Test if(exists(wpinstallation.ontargetmysqldb'stablename'sprefix'sextentions)==true){ $installerResult="fail"; errorpage("A Wordpress installation already exists on target MYSQL DB's Table Names with the Table Prefix you mentioned.Remove/Change the target MYSQL DB's Table Names with the Table Prefix you mentioned for this to work."); }
  //WPinstallationScript existence test
    //x.Test if(exists(wpinstallationscript.ontargetdirectory)==true){ $installerResult="fail"; errorpage("WPISCE on target Installation Directory.Remove all files on target Installation Directory or Try using a different target Installation Directory for this to work."); }
    //x.Test if(exists(wpinstallationscript.ontargetmysqldb'stablename'sprefix'sextentions)==true){ $installerResult="fail"; errorpage("<b>Error:</b>WPISCE on target MYSQL DB's Table Names with the Table Prefix you mentioned.Remove/Change the target MYSQL DB's Table Names with the Table Prefix you mentioned for this to work."); }

//Step3.Start Installation
    //Upload files
	//a.FTP(thezipped(wp && itstheme && selectedplugins && unzipperscript)).totargetplace()
	//note: remote files will remain in "install dir" because their "target dir" will be created after unzip of wordpress
	     //20.allocate zipped wordpress
		      $wp="wordpress-3.0.5.zip";
		 //21.allocate theme(if any)
			  if($_SESSION['selected_theme']=="none") //nothing was selected
			  {  $selectedtheme = "none";  }  else  { $selectedtheme = $_SESSION['selected_theme']; }
			  //echo "selected theme:".$selectedtheme; exit();
		 //22.allocate selected plugins(if any)
		      if($_SESSION['selected_plugins']=="none") //nothing was selected
			  {  $selectedplugin = "none"; }  else  { $selectedplugin = $_SESSION['selected_plugins']; }
		 //23.allocate unzipper script			   
			  $unzip='<?php
			   $f=$_GET["f"]; //file
			   $p=$_GET["p"]; //path

               $zip = new ZipArchive;
               $res = $zip->open($f);
               if ($res === TRUE) {
               $zip->extractTo($p);
               $zip->close();
               echo "ok";
               } else {
               die ("UNZip_Failed!");
               }
              ?>';
			  //create unzipper script
			  $junk = "junk/".$id."_unzip.php";
			  $fp=fopen($junk, 'w'); //Write to file	
			  fputs($fp, $unzip);
              fclose($fp); 
		 //24.ftp wordpress
		     //get wp
		     $wppath="upload/".$wp;
			 //load em
			 $file = $wppath; $remote_file = $wp;
             $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
             $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
             if (!ftp_put($conn_id, $ftp_InstallDirectory.$remote_file, $file, FTP_BINARY)) {       // close the connection
             ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/c cannot upload Wordpress. Try changing FTP A/c settings or FTP Details values."); exit(); }			
		 //25.ftp theme
		     //get theme
			 //echo "selected theme:".$selectedtheme; exit();
		     if($selectedtheme!="none");
			 {
			 //convert ref theme into .zip file 
			          //get zip file name and store in $selectedtheme
						 include("opendb.php");
						 $st= mysql_query("SELECT zip FROM themes WHERE (ref='".$selectedtheme."')");
						 if(!$st)
						 {
						 $installerResult="fail"; errorpage("MYSQL query cannot get selected theme of Wordpress. Contact site admin."); exit();
						 }
						 else
						 {
						 $trow = mysql_fetch_array($st);
						 $selectedtheme = $trow["zip"];
						 //its done
						 }
						 mysql_close($conn);
						 //echo "selected theme:".$selectedtheme; exit(); //works fine
			 $themepath="upload/themes/".$selectedtheme;
			             //upload theme
			 $file = $themepath; $remote_file = $selectedtheme;
             $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
             $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
             if (!ftp_put($conn_id, $ftp_InstallDirectory.$remote_file, $file, FTP_BINARY)) {       // close the connection
             ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/c cannot upload Theme. Try changing FTP A/c settings or FTP Details values."); exit(); }			
			 }
		 //26.ftp plugins one by one in a loop
		     if($selectedplugin!="none");
			 {
			    //upload plugins one by one
			    //build the loop
			 $plugins = $selectedplugin;
			 $play = explode("@", $plugins);
			   foreach($play as $key => $value )
               {
               //echo "Key: $key; Value: $value<br />\n"; //for unit testing only
                if ($key>0)
                {
				//convert ref into .zip
				         include("opendb.php");
						 $sp= mysql_query("SELECT ref FROM plugins WHERE (name='".$value."')");
						 if(!$sp)
						 {
						 $installerResult="fail"; errorpage("MYSQL query cannot get selected plugin of Wordpress. Contact site admin."); exit();
						 }
						 else
						 {
						 $prow = mysql_fetch_array($sp);
						 $value = $prow["ref"];
						 //its done
						 }
						 mysql_close($conn);
				
				$pluginpath="upload/plugins/".$value;
				//load em
				$file = $pluginpath; $remote_file = $value;
                $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
                $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
                if (!ftp_put($conn_id, $ftp_InstallDirectory.$remote_file, $file, FTP_BINARY)) {       // close the connection
                ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/c cannot upload Plugin:".$value.". Try changing FTP A/c settings or FTP Details values."); exit(); }			
                }
               }
			 }
		 //27.ftp unzipper script
		      $unzipperpath="junk/".$id.'_unzip.php'; $unzipper = 'unzipperscript.php';
			  //load em
			  $file = $unzipperpath; $remote_file = $unzipper;
              $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
              $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
              if (!ftp_put($conn_id, $ftp_InstallDirectory.$remote_file, $file, FTP_BINARY)) {       // close the connection
              ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/c cannot upload Unzipper script. Try changing FTP A/c settings or FTP Details values."); exit();}			
         //28.delete the junk folder file called unzipper script from my disk
			  $deljunk=unlink($unzipperpath);
			  if (!$deljunk) { $installerResult="fail"; errorpage("Site UnZipper Junk cannot be deleted. Try to contact site admin."); exit(); }
	
	
	//Unpack *.zip files, Delete *.zip files
	//echo "selected theme:".$selectedtheme; exit();
	         //whattoextract = [wordpress=$wp; theme=$selectedtheme; plugin=$selectedplugin;];
	//b.Unzip(them).ontargetserver(by running unzipperscript.php?f=file&p=path).ontargetserver()
	    //note: always extract in $p="" for "same dir" not $p="zipname/" and do in format $ex*path variables
	//b.a. and onsucessreturnmsg(Delete(the *.zips && unzipperscript))
	     //29. unzip wordpress & move wordpress files to parent folder in one shot ;) as the zip file is built from selecting *.* files+folders inside the folder and add to zip, not zipping the folder itself
		     //get settings
			  $exwp = $wp;
			  $exwppath ="./";
		     //run the file
		     $site_url= $_SESSION['site_url'];
			 $remote_file_param = "unzipperscript.php?f=".$exwp."&p=".$exwppath."";
			 $content = file_get_contents($site_url.$remote_file_param); 
	     //30.fetch file content	     
             if (!$content) { $installerResult="fail"; errorpage("Site URL relative to Wordpress location is incorrect. Try changing Site URL settings values."); exit(); } 
		 //31.check if unzip sucessfull	 
		     if ($content != "ok" ) { $installerResult="fail"; errorpage("Server Settings does not allow to Unzip Wordpress. Try changing Server Settings or Tell your hosting provider to enable Unzip system."); exit(); }
			 //echo "we got this:".$content; //exit(); //works fine
		 //32.onsuccess delete wordpress
             $file = $ftp_InstallDirectory.$wp;
			 //echo "wordpress 2 delete:".$file; exit();
             $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
             $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
             if (!ftp_delete($conn_id, $file)) { 
			 ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/c does not allow File Deletion of Wordpress. Try changing FTP A/c settings or FTP Details values."); exit(); }
		 //33.unzip theme(if any)
		      //get theme
			  //echo "selected theme:".$selectedtheme; exit();
		      if($selectedtheme !="none");
			  {
			             //get zip file name and store in $selectedtheme
						 //echo "selected theme:".$selectedtheme; exit();
			             //unzip theme
		      $extheme = $selectedtheme;
			  $exthemepath="wp-content/themes/"; //folder name automatically comes from zip extraction and its contents are placed inside it
			  //run the file
		      $site_url= $_SESSION['site_url'];
			  $remote_file_param = "unzipperscript.php?f=".$extheme."&p=".$exthemepath."";
			  //echo "theme param:".$remote_file_param; exit();
			  $content = file_get_contents($site_url.$remote_file_param);
              if (!$content) { $installerResult="fail"; errorpage("Site URL relative to Wordpress Theme location is incorrect. Try changing Site URL settings values."); exit(); } 
              else { 
	     //34.fetch file content
		        if ($content != "ok" ) { $installerResult="fail"; errorpage("Server Settings does not allow to Unzip Wordpress Theme. Try changing Server Settings or Tell your hosting provider to enable Unzip system."); exit(); }		 
			  }
			  }
		 //35.onsuccess delete theme(if any)
		      if($selectedtheme !="none");
			  {
	    	  $file = $ftp_InstallDirectory.$extheme; 
			  //echo "wordpress theme 2 delete:".$file; exit();
              $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
              $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
              if (!ftp_delete($conn_id, $file)) { 
			  ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/c does not allow File Deletion of Wordpress Theme. Try changing FTP A/c settings or FTP Details values."); exit(); }
			  }
		 //36.unzip plugins(if any) one by one
		      if($selectedplugin !="none");
			  {
			    //unzip plugins one by one
			    //build the loop
			   $plugins = $selectedplugin;
			   $play = explode("@", $plugins);
			   foreach($play as $key => $value )
               {
               //echo "Key: $key; Value: $value<br />\n"; //for unit testing only
                if ($key>0)
                {         
				//convert ref into .zip
				         include("opendb.php");
						 $sp= mysql_query("SELECT ref FROM plugins WHERE (name='".$value."')");
						 if(!$sp)
						 {
						 $installerResult="fail"; errorpage("MYSQL query cannot get selected plugin of Wordpress. Contact site admin."); exit();
						 }
						 else
						 {
						 $prow = mysql_fetch_array($sp);
						 $value = $prow["ref"];
						 //its done
						 }
						 mysql_close($conn);
						 
				          //unzip plugin
		        $explugin = $value;
			    $expluginpath="wp-content/plugins/"; //folder name automatically comes from zip extraction and its contents are placed inside it
				//run the file
				//echo "Site URL:".$site_url; exit();
		        //$site_url= $_SESSION['site_url']; no need to re-define $site_url
				//echo "Site URL:".$site_url; exit();
				
			    $remote_file_param = "unzipperscript.php?f=".$explugin."&p=".$expluginpath."";
			    $content = file_get_contents($site_url.$remote_file_param);
                if (!$content) { $installerResult="fail"; errorpage("Site URL relative to Wordpress Plugin location is incorrect. Try changing Site URL settings values."); exit(); } 
                else { 
	     //37.fetch file content
		        if ($content != "ok" ) { $installerResult="fail"; errorpage("Server Settings does not allow to Unzip Wordpress Plugin:".$value.". Try changing Server Settings or Tell your hosting provider to enable Unzip system."); exit(); }		 
			    }
			    }
               }
			  }
		 //38.onsuccess delete plugins(if any) one by one
		      if($selectedplugin !="none");
			  {
		       //build the loop
			   $plugins = $selectedplugin;
			   $play = explode("@", $plugins);
			   foreach($play as $key => $value )
               {
               //echo "Key: $key; Value: $value<br />\n"; //for unit testing only
                if ($key>0)
                {
				//convert ref into .zip
				         include("opendb.php");
						 $sp= mysql_query("SELECT ref FROM plugins WHERE (name='".$value."')");
						 if(!$sp)
						 {
						 $installerResult="fail"; errorpage("MYSQL query cannot get selected plugin of Wordpress. Contact site admin."); exit();
						 }
						 else
						 {
						 $prow = mysql_fetch_array($sp);
						 $value = $prow["ref"];
						 //its done
						 }
						 mysql_close($conn);
						 
				 $file = $ftp_InstallDirectory.$value; 
				 //echo "plugin 2 be deleted URL:".$file; exit();
                 $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
                 $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
                 if (!ftp_delete($conn_id, $file)) { 
			     ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/c does not allow File Deletion of Wordpress Plugin:".$value.". Try changing FTP A/c settings or FTP Details values."); exit(); }
                }
               }
			  }				
	     //39.on sucess end delete the unzipper script
		     //x.1 delete the one in site junk folder
			         // already done in point 25. above
		     //x.2 delete the one via ftp on target server
    		 $file = $ftp_InstallDirectory.$unzipper; 
			 //echo "unzipper 2 delete:".$file; exit();
             $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
             $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
             if (!ftp_delete($conn_id, $file)) { 
			 ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/c does not allow File Deletion of Wordpress Unzipper script. Try changing FTP A/c settings or FTP Details values."); exit(); }
	
	//Site Activation
//not required as the below can not be helpful to the site.
	//x.FTP(another custom non-gui based "hello.php" installerscript with wholeinfo of installation taken from Step 0 to Step 3 in logic diagram).ontargetserver() 
	//x.ftp the file && runit.ontargetserver as ("hello.php?t=wpconfig || t=wpinstall || t=theme ") //t=plugins not required as we are not working on plugins
					
		//a.wordpress config file building
			//40.build wp config file string
						$wpconfig='<?php
						/**
 						* The base configurations of the WordPress.
 						*
 						* This file has the following configurations: MySQL settings, Table Prefix,
 						* Secret Keys, WordPress Language, and ABSPATH. You can find more information
 						* by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 						* wp-config.php} Codex page. You can get the MySQL settings from your web host.
 						*
 						* This file is used by the wp-config.php creation script during the
 						* installation. You don\'t have to use the web site, you can just copy this file
 						* to "wp-config.php" and fill in the values.
 						*
 						* @package WordPress
 						*/
						
						// ** MySQL settings - You can get this info from your web host ** //
						/** The name of the database for WordPress */
						define(\'DB_NAME\', \''.$_SESSION["mysql_dbname"].'\');

						/** MySQL database username */
						define(\'DB_USER\', \''.$_SESSION['mysql_username'].'\');

						/** MySQL database password */
						define(\'DB_PASSWORD\', \''.$_SESSION['mysql_password'].'\');

						/** MySQL hostname */
						define(\'DB_HOST\', \''.$_SESSION['mysql_dbhost'].'\');

						/** Database Charset to use in creating database tables. */
						define(\'DB_CHARSET\', \'utf8\');

						/** The Database Collate type. Don\'t change this if in doubt. */
						define(\'DB_COLLATE\', \'\');

						/**#@+
 						* Authentication Unique Keys and Salts.
 						*
 						* Change these to different unique phrases!
 						* You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 						* You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 						*
 						* @since 2.6.0
 						*/
						define(\'AUTH_KEY\',         \'-%5?99!7=a#C=R&f^p4Cv{RfhH#TGW%lHi8Xb7 ObLd+1o7ReDvcFMHPRv5us?]w\');
						define(\'SECURE_AUTH_KEY\',  \'9nc/KM$tTVH@/[o9_X|Qv),#VlXB1v?NUE=o;t!mwrrx6[R [ZEa$ux:TU}V ,dY\');
						define(\'LOGGED_IN_KEY\',    \'xhys.7UczZfnA3uN^#0kG!DMCa5me.<ks]`olkfJ`NZflT@cO]b#oG+.5%B7XM:c\');
						define(\'NONCE_KEY\',        \'@9:GTv3dN^i:HmkF.<W,#V}p7$X ^Gl*Q7#]a`N$*IuAt!Dnkk*d:)M?;;oEX@h[\');
						define(\'AUTH_SALT\',        \'V>N{E$nP[srV%n*2Pb-XYSl Lsc|QOu?dr!7j[<da9XUElXa?bu:!J=nRFA,WDMJ\');
						define(\'SECURE_AUTH_SALT\', \'N{3I>&KZ8j<uoSIDg/*3=F`I~l*O;7p;8K=-{)pca^]&.M!KxxT|7wtc.k?^C,nd\');
						define(\'LOGGED_IN_SALT\',   \'TDe[&hI7*Lqk(Ht%Ucp#0J+*1wro,t=]@EDXWFqDe3?czhp,|{@ Y]?dvj4TX}+i\');
						define(\'NONCE_SALT\',       \'>zNp! [Gj5NQQ$vuN/hcVm<b[]oHUb`Qb18Km:2jL1u:],Mq27W6(}YrF#9ii _F\');

						/**#@-*/

						/**
 						* WordPress Database Table prefix.
 						*
 						* You can have multiple installations in one database if you give each a unique
 						* prefix. Only numbers, letters, and underscores please!
 						*/
						$table_prefix  = \'wp_\'; //declare table prefix
						
						/**
 						* WordPress Localized Language, defaults to English.
 						*
 						* Change this to localize WordPress.  A corresponding MO file for the chosen
 						* language must be installed to wp-content/languages. For example, install
 						* de.mo to wp-content/languages and set WPLANG to \'de\' to enable German
 						* language support.
 						*/
						define (\'WPLANG\', \'\');
						
						/**
 						* For developers: WordPress debugging mode.
 						*
 						* Change this to true to enable the display of notices during development.
 						* It is strongly recommended that plugin and theme developers use WP_DEBUG
 						* in their development environments.
 						*/
						define(\'WP_DEBUG\', false);
						
						/* That\'s all, stop editing! Happy blogging. */
						
						/** Absolute path to the WordPress directory. */
						if ( !defined(\'ABSPATH\') )
							define(\'ABSPATH\', dirname(__FILE__) . \'/\');
						
						/** Sets up WordPress vars and included files. */
						require_once(ABSPATH . \'wp-settings.php\');
						';//end of configfile     
                        
			//41.create the config file on server
			            $junk = "junk/".$id."_wp-config.php";
			            $fp=fopen($junk, 'w'); //Write to file	
			            fputs($fp, $wpconfig);
                        fclose($fp);
			//42.ftp it
						$configpath="junk/".$id.'_wp-config.php'; $configfile = 'wp-config.php';
			               //load em
			            $file = $configpath; $remote_file = $configfile;
                        $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
                        $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
                        if (!ftp_put($conn_id, $ftp_InstallDirectory.$remote_file, $file, FTP_BINARY)) {       // close the connection
                        ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/c cannot upload Wordpress Configuration file. Try changing FTP A/c settings or FTP Details values."); exit(); }			
			//43.delete junk from site only because the uploaded one will remain forever
			            $deljunk=unlink($configpath);
			            if (!$deljunk) { $installerResult="fail"; errorpage("Site WPConfig Junk cannot be deleted. Try to contact site admin."); exit(); }
						
	//b.wordpress db install 
			//44.build the dump file from stored > mysql details + stored upload/dump.ref + connection closing details
							// build connection()
							 $dumpfile = '<?php
							   // This is our database configuration file
							   $dbhost = "'.$_SESSION['mysql_dbhost'].'";
                               $dbuser = "'.$_SESSION['mysql_username'].'";
                               $dbpass = "'.$_SESSION['mysql_password'].'";
                               $dbname = "'.$_SESSION['mysql_dbname'].'";
						
							   $conn = mysql_connect($dbhost, $dbuser, $dbpass);

							   if (!$conn) {
							       die("Error connecting to mysql. Could not connect: " . mysql_error());
							   }
							   // echo "Connected successfully"; // Hide this when db everything works fine

							   mysql_select_db($dbname);
							 ';
							// get upload/dump.ref
							 $content = file_get_contents("./upload/dump.ref", FILE_USE_INCLUDE_PATH); 
							 if (!$content) { $installerResult="fail"; errorpage("MYSQL DUMP file CORRUPUTED. Try to contact site admin."); exit(); }
							 else { 
							       // we got the file content
							       // add It
								  $dumpfile = $dumpfile.$content;
     							  }
							 
							 
				 			// add connection closer
							 $dumpfile = $dumpfile.'
							 mysql_close($conn);
							  ?>
							 ';
			//45.create the dump file on server
							 $junk = "junk/".$id."_dump.php";
			                 $fp=fopen($junk, 'w'); //Write to file	
			                 fputs($fp, $dumpfile);
                             fclose($fp);
							 
							 
							 
			//46.ftp the dump to target server  
					    $dbdump= $junk;
			               //load em
			            $file = $dbdump; $remote_file = "dump.php";
                        $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
                        $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
                        if (!ftp_put($conn_id, $ftp_InstallDirectory.$remote_file, $file, FTP_BINARY)) {       // close the connection
                        ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/c cannot upload Wordpress SQL DUMP file. Try changing FTP A/c settings or FTP Details values."); exit(); }			
					  //delete the dump from junk folder
					    //code done later in program due to dependencies
							
	//b.b.import wordpress database into mysql on target server
			//47.build passthru, wp update and theme update file
							$passfile = '<?php
							   $t=$_GET["t"];
							   $dbhost = "'.$_SESSION['mysql_dbhost'].'";
                               $dbuser = "'.$_SESSION['mysql_username'].'";
                               $dbpass = "'.$_SESSION['mysql_password'].'";
                               $dbname = "'.$_SESSION['mysql_dbname'].'";
							   
							   $site_email = "'.$_SESSION['site_email'].'";
							   $site_title = "'.$_SESSION['site_title'].'";
							   $site_url= "'.$_SESSION['site_url'].'";
							   $site_google= "'.$_SESSION['site_visibletosearchengines'].'";
							   $selectedtheme= "'.$selectedtheme.'";
							   
							   $conn = mysql_connect($dbhost, $dbuser, $dbpass);
                               if (!$conn) { die("Error connecting to mysql. Could not connect: ");}
                               // echo "Connected successfully"; // Hide this when db everything works fine
                               mysql_select_db($dbname);
							   
							   if($t=="importmysql")
							   {
	                              //include("dump.php");
								  //get the echo of dump file
								  $remote_file_param = "dump.php";
								  $content = file_get_contents($site_url.$remote_file_param);
								  //echo "import content:".$content; exit();
								  if (!$content) {   die("MYSQL_IMPORT_FILE_CORRUPTED!"); }
								  else { 
								  //fetch file content
								  if ($content==trim("MYSQL_IMPORT_FAILED!")) {   die("MYSQL_IMPORT_FAILED!"); }
     							  }
							   
							   echo "abhishekjha.net";
							   }
							   if($t=="updatesiteinfo")
							   {
							   
							   		//admin as a user email
							   			$sql= "UPDATE    wp_users
                               			SET  user_email = \'".$site_email."\' 
                               			WHERE        (ID = 1)";    //echo $sql;	  
                               			if (!mysql_query($sql,$conn))
                               			{   die("updatesiteinfo_Error!"); } //echo "records updated";
										
									//user password
									    $sql= \'UPDATE wp_users
										SET  user_pass = "$P$BqkYJFde56FU72nNLQws9lRgODR20N1" 
										WHERE (ID = 1)\';   
                               			if (!mysql_query($sql,$conn))
                               			{   die("updatesiteinfo_Error!"); } //echo "records updated";
							   
							   		//site visible to google
							   			$sql= "UPDATE    wp_options
                               			SET  option_value = \'".$site_google."\' 
                               			WHERE        (option_name = \'blog_public\')";    //echo $sql;	  
                               			if (!mysql_query($sql,$conn))
                               			{   die("updatesiteinfo_Error!"); } //echo "records updated";
							   
							   		//site url
							   			$sql= "UPDATE    wp_options
                               			SET  option_value = \'".$site_url."\' 
                               			WHERE        (option_name = \'siteurl\')";    //echo $sql;	  
                               			if (!mysql_query($sql,$conn))
                               			{   die("updatesiteinfo_Error!"); } //echo "records updated";
							   
							   		//home url
							   			$sql= "UPDATE    wp_options
                               			SET  option_value = \'".$site_url."\' 
                               			WHERE        (option_name = \'home\')";    //echo $sql;	  
                               			if (!mysql_query($sql,$conn))
                               			{   die("updatesiteinfo_Error!"); } //echo "records updated";
							   
							   		//sitename
							   			$sql= "UPDATE    wp_options
                               			SET  option_value = \'".$site_title."\' 
                               			WHERE        (option_name = \'blogname\')";    //echo $sql;	  
                               			if (!mysql_query($sql,$conn))
                               			{   die("updatesiteinfo_Error!"); } //echo "records updated";
							   
							   		//admin email
							   			$sql= "UPDATE    wp_options
                               			SET  option_value = \'".$site_email."\' 
                               			WHERE        (option_name = \'admin_email\')";    //echo $sql;	  
                               			if (!mysql_query($sql,$conn))
                               			{   die("updatesiteinfo_Error!"); } //echo "records updated";
							   
							   echo "abhishekjha.net";
							   }
							   if($t="theme")
							   {
							      if($selectedtheme!="none");
			                      {
		                          		$template= substr($selectedtheme,0,(strlen($selectedtheme)-4)); // remove the .zip postfix
			 
							      		//template
								  		$sql= "UPDATE    wp_options
                                  		SET  option_value = \'".$template."\' 
                                  		WHERE        (option_name = \'template\')";    //echo $sql;	  
                                  		if (!mysql_query($sql,$conn))
                                  		{   die("updatesiteinfoError:"); } //echo "records updated";
								  
							      		//stylesheet
								  		$sql= "UPDATE    wp_options
                                  		SET  option_value = \'".$template."\' 
                                  		WHERE        (option_name = \'stylesheet\')";    //echo $sql;	  
                                  		if (!mysql_query($sql,$conn))
                                  		{   die("updatesiteinfoError:"); } //echo "records updated";
								  
							      		//current theme // get theme name from style.css
								  ';
								  		include("opendb.php");
								  		$st= mysql_query("SELECT styledotcssthemename FROM themes WHERE (zip='".$selectedtheme."')", $conn);
						          		if(!$st)
						          		{
						          		$installerResult="fail"; errorpage("MYSQL cannot select current theme. Contact site admin."); exit(); //echo "records updated";
						          		}
						          		else
						          		{
								  		$trow = mysql_fetch_array($st);
						          		$selectedtheme = $trow["styledotcssthemename"];
								  		//its done
						          		}
								  
							      		mysql_close($conn);	  
								  
								  		$passfile = $passfile.'
								  		
										//current theme update
								  		$sql= "UPDATE    wp_options
                                  		SET  option_value = \''.$selectedtheme.'\' 
                                  		WHERE        (option_name = \'current_theme\')";    //echo $sql;	  
                                  		if (!mysql_query($sql,$conn))
                                  		{   die("updatesiteinfoError:"); } //echo "records updated";
							      
								  echo "abhishekjha.net";
							      }
							   }
							   
							   mysql_close($conn);
							   ?>';
							   
			 //48.create the passr file on server
			                 $junk = "junk/".$id."_passr.php";
			                 $fp=fopen($junk, 'w'); //Write to file	
			                 fputs($fp, $passfile);
                             fclose($fp);
			 //49.ftp it
							 $actpath = $junk; $actfile = 'passr.php';
			                      //load em
			                 $file = $actpath; $remote_file = $actfile;
                             $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
                             $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
                             if (!ftp_put($conn_id, $ftp_InstallDirectory.$remote_file, $file, FTP_BINARY)) {       // close the connection
                             ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/c cannot upload Wordpress Activation file. Try changing FTP A/c settings or FTP Details values."); exit(); }			
                             
			 //50.run it for pass thru
						        //$site_url= $_SESSION['site_url'];	//echo "site url:".$site_url; exit();
			                    $remote_file_param = "passr.php?t=importmysql";
			                    $content = file_get_contents($site_url.$remote_file_param);
								//echo "passr link:".$site_url.$remote_file_param; exit();
                                if (!$content) { $installerResult="fail"; errorpage("Site URL relative to Wordpress MYSQL Activator location is incorrect. Try changing Site URL settings values."); exit(); } 
                                else { 
	      //fetch file content
		     //51.check currupted file
		                     if ($content==trim("MYSQL_IMPORT_FILE_CORRUPTED!")) { $installerResult="fail"; errorpage("Server Settings are invalid and so MYSQL IMPORT FILE HAS GOT CORRUPTED!. Try changing Server Settings or Tell your hosting provider to enable MYSQL IMPORT system."); exit(); }		 
			 //52.check error				 
							 if ($content==trim("MYSQL_IMPORT_FAILED!")) { $installerResult="fail"; errorpage("Server Settings does not allow to IMPORT Wordpress MYSQL db. Try changing Server Settings or Tell your hosting provider to enable MYSQL IMPORT system."); exit(); }		 
			                 }
													 
			 //53.run it for wp
                                //$site_url= $_SESSION['site_url'];
			                    $remote_file_param = "passr.php?t=updatesiteinfo";
			                    $content = file_get_contents($site_url.$remote_file_param);
                                if (!$content) { $installerResult="fail"; errorpage("Site URL relative to Wordpress WP Activator location is incorrect. Try changing Site URL settings values."); exit(); } 
                                else { 
	         //54.fetch file content
		                     if ($content==trim("updatesiteinfo_Error!")) { $installerResult="fail"; errorpage("Server Settings does not allow to Update of Wordpress MYSQL db. Try changing Server Settings or Tell your hosting provider to enable MYSQL Update system."); exit(); }		 
			                 }
							 
			 //55.run it for theme
							    //$site_url= $_SESSION['site_url'];
			                    $remote_file_param = "passr.php?t=theme";
			                    $content = file_get_contents($site_url.$remote_file_param);
                                if (!$content) { $installerResult="fail"; errorpage("Site URL relative to Wordpress Theme Activator location is incorrect. Try changing Site URL settings values."); exit(); } 
                                else { 
             //56.check sucess output 								
							 if ($content==trim("updatesiteinfoError:")) { $installerResult="fail"; errorpage("Server Settings does not allow to Theme Update of Wordpress MYSQL db. Try changing Server Settings or Tell your hosting provider to enable MYSQL Update system."); exit(); }		 
			                 }
							 
 //delete it
		//the dump file()
			 //57.the site junk
								        $deljunk=unlink($dbdump);
			                            if (!$deljunk) { $installerResult="fail"; errorpage("Site WPDUMP Junk cannot be deleted. Try to contact site admin."); exit(); }
			 //58.the ftp uploaded dump file()
										$remote_file = "dump.php";
										$conn_id = ftp_connect($ftp_hostname); // set up basic connection 
                                        $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
			                            $delfileviaftp= $ftp_InstallDirectory.$remote_file;
			                            if (!ftp_delete($conn_id, $delfileviaftp)) {ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/C does not allow WPDUMP file deletion. Try changing FTP settings/permissions for installation process to work."); exit(); }
										
		//the passr file()	  
			 //59.the site junk			   
								        $deljunk=unlink($actpath);
			                            if (!$deljunk) { $installerResult="fail"; errorpage("Site Passr Junk cannot be deleted. Try to contact site admin."); exit(); }
			 //60.the ftp uploaded passr file()
								        $remote_file = $actfile;
                                        $conn_id = ftp_connect($ftp_hostname); // set up basic connection 
                                        $login_result = ftp_login($conn_id, $ftp_username, $ftp_password); // login with username and password
			                            $delfileviaftp= $ftp_InstallDirectory.$remote_file;
			                            if (!ftp_delete($conn_id, $delfileviaftp)) {ftp_close($conn_id); $installerResult="fail"; errorpage("FTP A/C does not allow Passr file deletion. Try changing FTP settings/permissions for installation process to work."); exit(); }
			  
				      										
	
	//there is nothing to do in plugins since activation can cause menu overflow problem
	//				//x.linking and activation of plugins in wp db one-by-one(if any)
					      //x.a.(they will create their own db tables)
					      //x.b.put info of site in plugins db and also plugin usage on particular pages info in site db to make it work with site
	// this is assumed to be sucessfull for serial flow order //x.and this will return value either "sucessfull" or "failure" back to its parent function.
	          					  
	//Work on Installer Result
	  //if(installerResult=="fail")
	  //{
	    //do nothing.. the below is useless piece of code
	  	//$installerResult="fail"; errorpage("Installation has resulted in a failure for Your User ID:".$id.". Try to re-install or contact site admin."); } //echo "records updated";	
	  //}
	  if(installerResult!="fail")
	  { 
	  // Delete.that_installerfile("hello.php").via_ftp();	// not required as step is done beforehand
	  
	  //Reset progress bar to 0
 //Add +35 to progress bar
	  //61.Updaterecord usersaldo-=1, 
	     //open database
		 include("opendb.php");
		 //get userid
		 //update record
		 $sql= "UPDATE    users
         SET  Saldo = '".($saldo-1)."' 
         WHERE        (ID = '".$id."')";    //echo $sql;	  
         if (!mysql_query($sql,$conn))
         {   $installerResult="fail"; errorpage("SALDO value cannot be updated for Your User ID:".$id.". Try to contact site admin."); exit(); } //echo "records updated";
	  
	  //62.Updaterecord NoOfInstalls.doneBy(serialno)+=1;
	     //update record
		 $sql= "UPDATE    users
         SET  Used = '".($used+1)."' 
         WHERE        (ID = '".$id."')";    //echo $sql;	  
         if (!mysql_query($sql,$conn))
         {   $installerResult="fail"; errorpage("USED value cannot be updated for Your User ID:".$id.". Try to contact site admin."); exit(); } //echo "records updated";
	  
	  //63.Mail.a.copy(of this sucessMessage).totargetuser'sEmailID;
	     //get info of user who to mail
	     //build success mail msg
         $headers  = "MIME-Version: 1.0" . "\r\n";
         $headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
         //     $to = $user_email;
	     $to = "To: ".$name." <".$user_email.">";
         $subject = "Gefuso.com - NEW Wordpress Site Creation Details!";	 
         $message = "Hello ".$name.",<br/>
	             <p><big>Congratulations!!</big> You have sucessfully created a new Wordpress site using our Installation System.</p><br/>				 
				 <p>Your <b>ADMIN LOGIN ID</b> is:<b>admin</b></p>
				 <p>Your <b>ADMIN LOGIN PASSWORD</b> is:<b>admin</b></p>
				 <p>Please note down your ADMIN LOGIN ID and PASSWORD. It is very important in the process.</p>
				 <p>You can now goto <a href=\"".$_SESSION['site_url']." \">".$_SESSION['site_url']."</a> and see your newly installed wordpress site with the theme and many plugins of your choice that we have added for you.<br/>
				 <br/><b>Most Importantly</b>:<br/>
				 1.You can login into your site administration control panel at <a href=\"".$_SESSION['site_url']."wp-login.php\">".$_SESSION['site_url']."wp-login.php</a> using the ADMIN ID and PASSWORD we mentioned above and modify your site and also the ID and PASSWORD we gave you.<br/>
				 2.You need to chmod INSTALL directory:<b>$ftp_InstallDirectory</b> back to 0755 or lower access permission for increased/higher security of this folder.<br/>
				 Furthermore, If you loose your <b>ADMIN ID or PASSWORD</b>, then contact me at my e-mail mentioned at the bottom of the message.</p>
				 <p>Best Regards,<br/>
				 Fabio - Fabio [at] Gefuso.com</p>";
     
         $headers .= "From: Gefuso Support <support@gefuso.com>";
	     //64.send mail
         if(!mail($to,$subject,$message,$headers))
	     { $installerResult="fail"; errorpage("User Information mail cannot be sent for Your User ID:".$id.". Try to contact site admin."); exit(); }
         else {	  //echo "Mail Sent.";
	     }
		 
	     //65.close db
		 mysql_close($conn);
	  
	  // Show.a.nice_sucessMessage(with targetuser's new wpAdmin ID && Password && SiteLinks);
	     //redirect to message page
		 printf("<script>location.href='installsuccess.php'</script>");

		 	  
	  }
 	
   } 
   //End of Elseif Saldo Check & End Of Program
?>