<?php
include("sessionchecker.php");
?>
<html>
<head>
<script type="text/javascript" src="./js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="./js/jquery.paginatetable.js"></script>
<SCRIPT LANGUAGE="JavaScript">
<!--

if (window != top) top.location.href = location.href;

// -->
</SCRIPT>
<script type="text/javascript">
$(document).ready(function () {
$('#myTable').paginateTable({ rowsPerPage: 2 });
});
</script>
<script type="text/javascript">
function addLoadEvent(func) {
  var oldonload = window.onload;
  if (typeof window.onload != 'function') {
    window.onload = func;
  } else {
    window.onload = function() {
      if (oldonload) {
        oldonload();
      }
      func();
    }
  }
}
</script>
<style type="text/css">
     div.blox:hover {background-color:#d4dded; border:1px dotted #cdcdcd; width:188px;}
</style>
</head>
<body>
<?php
//check if form submit set session values
if ((isset($_POST['Submit'])))// AND ($_GET['back']!="true"))  // $_GET['back']=="true" then we still show form else goto installer
{
// you should inspect these variables before passing off to mySQL

//start of ftp enter()
$_SESSION['ftp_username'] = $_POST['ftp_username'];
$_SESSION['ftp_password'] = $_POST['ftp_password'];
$_SESSION['ftp_hostname'] = $_POST['ftp_hostname'];
$_SESSION['ftp_InstallDirectory'] = $_POST['ftp_InstallDirectory'];
//start of mysql enter()
$_SESSION['mysql_dbname'] = $_POST['mysql_dbname'];
$_SESSION['mysql_username'] = $_POST['mysql_username'];
$_SESSION['mysql_password'] = $_POST['mysql_password'];
$_SESSION['mysql_dbhost'] = $_POST['mysql_dbhost'];
$_SESSION['mysql_tableprefix'] = $_POST['mysql_tableprefix'];
//site configurations enter()
$_SESSION['site_title'] = $_POST['site_title'];
$_SESSION['site_url'] = $_POST['site_url'];
  //we dont need to set user pass
  //$_SESSION['site_username'] = $_POST['site_username'];
  //$_SESSION['site_password'] = $_POST['site_password'];
$_SESSION['site_email'] = $_POST['site_email'];
if(isset($_POST['site_visibletosearchengines']) && 
 	 $_POST['site_visibletosearchengines'] == 'Yes') 
	{
	    //echo "Yes.";
		$_SESSION['site_visibletosearchengines'] = "1";
	}
else
	{
	    //echo "No.";
		$_SESSION['site_visibletosearchengines'] = "0";
	}	
//theme choice enter()
if(isset($_POST['theme']))
    {
	$_SESSION['selected_theme'] = $_POST['theme']; 
	}
	else
	{  //no theme was selected so default will be installed
	//$_SESSION['selected_theme'] = "none";
	$_SESSION['selected_theme'] = "business-achievements-bue062-2.21";
	}
//print "Selected Theme:".$_SESSION['selected_theme'];// for unit testing only	
//plugins choice enter()
//get the list of plugins selected
// 2>find checkbox values, combine them with '@' and '.' and store in a string
$curp = "";         
		 if(isset($_POST['formDoor']))
         {
		    $aDoor = $_POST['formDoor'];
    
            $N = count($aDoor);
            ////echo("You selected $N door(s): ");
            
			include("opendb.php");
            for($i=0; $i < $N; $i++)
            {
            //echo($aDoor[$i] . " ");
            $curp = $aDoor[$i];
            $result = mysql_query("SELECT name FROM plugins WHERE ref='".$curp."'")  or die(mysql_error());
			$row = mysql_fetch_array($result);
			$plugins = $plugins."@".$row["name"];
            }
            mysql_close($conn);
	        
         }
		 else
		 {
		 //no plugin were selected, so default will be installed
		 $plugins="none";
		 }
$_SESSION['selected_plugins']=$plugins;
//print "Selected plugins:".$_SESSION['selected_plugins']; //for unit testing only

//redirect to installer
	      printf("<script>location.href='install.php'</script>");	
}
//form submitted


//step 1.a show allowed domain
//$serial="Yahoo";
$serial=$_SESSION['userserial'];

include("opendb.php"); 
$result = mysql_query("SELECT Name,Domain FROM users WHERE Serial='".$serial."'")  or die(mysql_error());
$row = mysql_fetch_array($result);
$name= $row["Name"];
$domain= $row["Domain"];
mysql_close($conn); ?>

<!--//start of form-->
<div style="margin-left:50px;width:890px; border:0px dashed #efefef; text-align:center;">
<div style ="padding-left:20px;padding-right:20px; text-align:left;">
<?php
print ("<form name=\"sports\" action=\"$PHP_SELF\" method=\"POST\">");
//step 1.b Enter your following site details: ftp, site, mysql
print "
<table style=\"width:100%; border:0px solid #000; font-family:Arial;\">
    <tr>
        
    <td>
<h2>
    Welcome <span style=\"color:#808080;\">".$name."</span></h2>
    <span style=\"font-size:11px; padding-right:50px;\">Welcome to the famous five minute WordPress installation process!
	Just fill in the information below and you&#39;ll be on your way to using the most extendable and powerful personal 
    publishing platform in the world.</span>
	</td>
	<td>
<h1>
    <img alt=\"WordPress\" 
        src=\"./images/wpis.png\" /></h1>
			</td>	    
    </tr>
</table>
<div style=\"font-family:Arial;\">
<h1>
    Information needed</h1>
<p>
    Please provide the following information. Don&#39;t worry, you can always change 
    these settings later.</p>
</div>
<hr/>"; ?>

<!--//site configurations enter():-->
<p>
<div style="font-family:Arial;font-size:24px;"><img src="./images/site.png"> Enter SITE info:</div>
<table style="width:850px; border:0px solid #000;">
    <?php   print"
    <tr>
        <td>
            <b>
            Site Title:</b></td>
        <td>
            <input id=\"site_title\" name=\"site_title\" style=\"width: 200px;\" type=\"text\" value=\""; if(isset($_SESSION['site_title'])){print $_SESSION['site_title']; } else {print "Johnsons Website";} print "\" /></td>
		<td>
		    It can be <b>Johnsons Website</b>, <b>Music Fan Website</b>, <b>Game Lovers Zone</b>, etc.
		</td>	
    </tr>
	<tr>
        <td>
            <b>Domain Name:</b></td>
        <td>
            <big>".$domain."</big></td>
	    <td>
            This is taken from your User Account&#39;s <b>Allowed Domain</b> Info.
        </td>
    </tr>
	<tr>
        <td>
            <b>Site URL:</b></td>
        <td>
            <input id=\"site_url\" name=\"site_url\" style=\"width: 200px;\" type=\"text\" value=\""; if(isset($_SESSION['site_url'])){print $_SESSION['site_url']; } else {print $domain."/";} print "\" /></td>
		<td>
            The link where you will see ur wordpress site on the web. Add forward-slash(\"/\") suffix.</td>
    </tr>
	<tr>
        <td colspan=\"3\" style=\"border:1px solid rgb(230,219,85); background-color:rgb(255,255,224);\">
		<b>HINT:</b> The <b>Site URL</b> value above can be either:
		<ol>
		<li>Same as <b>Domain Name</b> above.</li>
		<li>Any <b>Subdomain of Domain Name</b>  above.</li>
		<li>Any <b>Subfolder of Domain Name</b> above.</li>
		<li>Any <b>Addon Domain which points to a Subfolder OR Subdomain of Domain Name</b> above.</li>
		<li>Any <b>Parked Domain which points Directly to Domain Name</b> above.</li>
		</ol>
		In short, just make sure that your <b>Site URL</b> is related to <b>Domain Name</b> as mentioned above and is reacheable via web browser.
		</td>
	</tr>	
    <tr>
        <td>
            <b>
            Your E-mail:</b></td>
        <td>
            <input id=\"site_email\" name=\"site_email\" style=\"width: 200px;\" type=\"text\" value=\""; if(isset($_SESSION['site_email'])){print $_SESSION['site_email']; } else {print "hello@johndoe.com";} print "\" /></td>
            <td>
                Double-check your email address before continuing.</td>
        
    </tr>
    <tr>
        <td colspan=\"3\">
            <b>
            <input id=\"site_visibletosearchengines\" name=\"site_visibletosearchengines\" type=\"checkbox\" value=\"Yes\" /> Allow 
            my site to appear in search engines like Google and Technorati.</b>
			"; 
			print "
<script type=\"text/javascript\">
";
if(isset($_SESSION['site_visibletosearchengines']) && $_SESSION['site_visibletosearchengines'] == "1")
{
print "document.getElementById(\"site_visibletosearchengines\").checked=true;";	
} 

elseif(isset($_SESSION['site_visibletosearchengines']) && $_SESSION['site_visibletosearchengines'] == "0")
{print "document.getElementById(\"site_visibletosearchengines\").checked=false;";}
print "
</script>";
print "			
		</td>
    </tr>"; ?>
</table>
</p>
<hr/>
<!--//end of site configurations-->

<!--//start of mysql enter():-->
<div style="font-family:Arial;font-size:24px;"><img src="./images/mysql.png"> Enter MYSQL info:</div>
<table style="width:850px; border:0px solid #000;">
<?php print"
   <tr>
        <td>
            <b>Database Name:</b>
        <td>
            <input id=\"mysql_dbname\" name=\"mysql_dbname\" style=\"width: 200px;\" type=\"text\" value=\""; if(isset($_SESSION['mysql_dbname'])){print $_SESSION['mysql_dbname']; } else {print "wordpress";} print "\" /></td>
        <td>
            The name of the database you want to run WordPress in.
        </td>
    </tr>
    <tr>
        <td>
            <b>User Name:</b></td>
        <td>
            <input id=\"mysql_username\" name=\"mysql_username\" style=\"width: 200px;\" type=\"text\" value=\""; if(isset($_SESSION['mysql_username'])){print $_SESSION['mysql_username']; } else {print "username";} print "\" /></td>
        <td>
            Your MySQL username</td>
    </tr>
    <tr>
        <td>
            <b>Password:</b></td>
        <td>
            <input id=\"mysql_password\" name=\"mysql_password\" style=\"width: 200px;\" type=\"text\" value=\""; if(isset($_SESSION['mysql_password'])){print $_SESSION['mysql_password']; } else {print "password";} print "\" /></td>
        <td>
            ...and MySQL password.</td>
    </tr>
    <tr>
        <td>
            <b>Database Host:</b></td>
        <td>
            <input id=\"mysql_dbhost\" name=\"mysql_dbhost\" style=\"width: 200px;\" type=\"text\" value=\""; if(isset($_SESSION['mysql_dbhost'])){print $_SESSION['mysql_dbhost']; } else {print "localhost";} print "\" /></td>
        <td>
            You should be able to get this info from your web host, if <b>localhost</b> 
            does not work.</td>
    </tr>"; ?>
</table>
<hr/>
<!--//end of mysql enter():-->

<!--//start of ftp enter():-->
<div style="font-family:Arial;font-size:24px;"><img src="./images/ftp.png"> Enter FTP info:</div>
<table style="width:850px; border:0px solid #000;">
<?php
print "
    <tr>
        <td>
            <b>Domain Name:</b></td>
        <td>
            <big>".$domain."</big></td>
	    <td>
            This is taken from your User Account&#39;s <b>Allowed Domain</b> Info.
        </td>
    </tr>
    <tr>
        <td>
            <b>FTP Username:</b></td>
        <td>
            <input id=\"ftp_username\" name=\"ftp_username\" style=\"width: 200px;\" type=\"text\"  value=\""; if(isset($_SESSION['ftp_username'])){print $_SESSION['ftp_username']; } else {print "username";} print "\" /></td>
		<td>
            Your FTP username</td>
    </tr>
    <tr>
        <td>
            <b>FTP Password:</b></td>
        <td>
            <input id=\"ftp_password\" name=\"ftp_password\" style=\"width: 200px;\" type=\"text\" value=\""; if(isset($_SESSION['ftp_password'])){print $_SESSION['ftp_password']; } else {print "password";} print "\" /></td>
		<td>
            ...and FTP password.</td>
    </tr>
    <tr>
        <td>
            <b>FTP Hostname:</b></td>
        <td>
            <input id=\"ftp_hostname\" name=\"ftp_hostname\" style=\"width: 200px;\" type=\"text\" value=\""; if(isset($_SESSION['ftp_hostname'])){print $_SESSION['ftp_hostname']; } else {print "ftp.".substr($domain,7,strlen($domain))."";} print "\" /></td>
		<td>
            Try <b>ftp.DomainName</b> or <b>DomainName</b> value above without <b>\"http://\"</b> prefix.</td>
    </tr>
    <tr>
        <td>
            <b>Installation Directory:</b></td>
        <td>
            <input id=\"ftp_InstallDirectory\" name=\"ftp_InstallDirectory\" style=\"width: 200px;\" type=\"text\" value=\""; if(isset($_SESSION['ftp_InstallDirectory'])){print $_SESSION['ftp_InstallDirectory']; } else {print "/public_html/";} print "\" /></td>
		<td>
            You can try <b>/</b>, if <b>/public_html/</b> 
            doesn&#39;t work.</td>
    </tr>
	<tr>
        <td colspan=\"3\" style=\"border:1px solid rgb(230,219,85); background-color:rgb(255,255,224);\">
		<b>HINT:</b> The formula is:<br/>
		Internally files will be transferred to <<b>FTP Hostname</b>> at <<b>Installation Directory</b>> path on your server<br/>
		.. but Externally they will be visible on <<b>Site URL</b>> you mentioned above<br/>
		<br/>
		In short, just make sure that your combined path of <<b>FTP Hostname</b>> and <<b>Installation Directory</b>> path ...<br/>... is the internal address(server path) from where the files of <b>Site URL</b>(that you entered above) will be served by the server...<br/>... to the user's web browser.
		</td>
	</tr>
	
	";?>
</table>
<hr/>
<!--//end of ftp enter():-->

<!--//theme choice enter();-->
<p>
<div style="font-family:Arial;font-size:24px;"><img src="./images/theme.png"> Choose a THEME you like:</div>
<!--//print ("<form name=\"theme\" action=\"$PHP_SELF\" method=\"POST\">"); // for unit testing only-->
<table style="width: 820px;height: 552px; border-style: solid; border-width: 0px;">
               <tr>
                   <td style="width:210px; text-align:center;" >


<table id="myTable" style="width:200px;text-align:center;">
     <tbody>
<?php
include("opendb.php");

$countresult = mysql_query("SELECT COUNT(ref) FROM themes")  or die(mysql_error());
$count= intval(mysql_result($countresult,0));
//echo "count = ".$count; for unit testing only

$result = mysql_query("SELECT name,ref FROM themes")  or die(mysql_error());

for ($i = 1; $i<=$count; $i++)
{
$row = mysql_fetch_array($result);
print "<tr><td><div class=\"blox\"><div style=\"text-align:left;\">";
print "<input type=\"radio\" name=\"theme\" id=\"".$row["ref"]."\" value=\"".$row["ref"]."\" >".$row["name"].""."<br/></div>"; // for radio button
print "<a href=\"./images/themes/".$row["ref"]."-large.png\" target=\"show\"><image src=\"./images/themes/".$row["ref"]."-small.png\" alt=\"\" style=\"border:0px;\" /></a>";
print "</div></td></tr>";
}
mysql_close($conn);
?>
    </tbody>
    </table>
    <div class='pager' style="text-align:center;">
	    <table width="100%;" style="font-family:Arial;font-weight:bold;font-size:14px;" ><tr>
        <td><a href='#' alt='Previous' class='prevPage' style="text-decoration:none;"><img src="./images/previous.png" style="border:0px;" /></a></td>
        <td> Page <span class='currentPage'></span> of <span class='totalPages'></span></td>
        <td><a href='#' alt='Next' class='nextPage' style="text-decoration:none;"><img src="./images/next.png" style="border:0px;" /></a></td>
		</tr></table>
    </div>
    
    <script>
    
    $(document).ready(function () {
        $('#myTable').paginateTable({ rowsPerPage: 3 });
    });
    </script>



                        </td>

                   <td style="width:610px;">

<div style="font-family:Arial; font-size:32px;">&nbsp;Preview:</div>
<iframe src ="./images/themes/notheme.png" width="608px;" height="500px;" scrolling="no" frameborder="0" name="show" >
<p>Your browser does not support iframes.</p>
</iframe>
                       </td>
               </tr>
           </table>
<b>Note:</b> You must click and mark the rounded-radio button of any theme above to select it. You can see this rounded-radio button just before the theme&#39;s name on the same line of the theme's name. If you do not select any theme, then <b>Business Achievements</b> theme will be installed!
</p>
<?php
if($_SESSION['selected_theme']!="none")
{
	//select its radio button
				print "
<script type=\"text/javascript\">

function theme_code(){
";
print "document.getElementById(\"".$_SESSION['selected_theme']."\").checked=true;";  
print "
}

addLoadEvent(theme_code);
</script>";

	//print "checked radio"; //for unit test only
	//paginate to page 2 if necessary
print " <script type=\"text/javascript\">";
	if ($_SESSION['selected_theme']=="eDegree-1.1" || $_SESSION['selected_theme']=="island-two-palm-trees-lae048-2.21" || $_SESSION['selected_theme']=="WSC6-1.0.5")
	{
	    
		//print "	"; //do something to force paginator to load page 2, see rohitsengars blog on cueblocks site.
	}

print "</script>";
	
}
?>
<hr/>
<!--//end of theme choice();-->

<!--//plugins choice enter();-->
<p >
<?php

//check plugins
include("opendb.php");
                    // SELECT pluginsallowed FROM users WHERE Serial = 'Yahoo'
	   //SELECT pluginsallowed FROM users    WHERE Serial = '5NSZC9NLG14EJCGDY3LA'
$result = mysql_query("SELECT pluginsallowed FROM users WHERE Serial='$serial'")  or die(mysql_error());
$row = mysql_fetch_array($result);
$plugins=$row["pluginsallowed"];
$play = explode("@", $plugins);
?>
<table style="width:100%;">
<div style="font-family:Arial;font-size:24px;"><img src="./images/plugin.png"> Choose the PLUGINS you want:</div>
<?php
//echo sizeof($play);

if (sizeof($play)==1)
{
			print "<tr>";
			print "<td><b>Sorry You Cannot Choose Plugins!</b> because your user account does not have any plugins assigned to it.</td>";
			print "</tr>";
			print "<tr>";
			print "<td><div style=\"float:right;\">................but the good news is that you can still install WordPress below!</div></td>";
			print "</tr>";
}
else if (sizeof($play)>1)
{
    foreach($play as $key => $value )
    {
      //echo "Key: $key; Value: $value<br />\n"; //for unit testing only && value = name but not ref

        if ($key>0) // values come from $key 1 onwards
        {    
            //echo $value; //for unit testing only
			
			//check plugins ref
            $result2 = mysql_query("SELECT ref FROM plugins WHERE name='$value'")  or die(mysql_error());
            $row2 = mysql_fetch_array($result2);
            //echo $row2["ref"]; //for unit testing only
			//print plugin
			print "<tr>";
            print "<td><input type=\"checkbox\" name=\"formDoor[]\" value=\"".$row2["ref"]."\" id=\"".$value."\" />" . $value . "</td>";
			print "</tr>";
        }
		

     }
	 print "<tr>";
	 print "<td><b>Note:</b> If you do not choose any plugins above, then the default WordPress Plugins will be installed.</td>";
	 print "</tr>";
}
mysql_close($conn); ?>
<?php
//get the list of checked plugins
if($_SESSION['selected_plugins']!="none");
{
			    //get plugins one by one
			    //build the loop
print "
<script type=\"text/javascript\">

function pluginc_code(){
";
			   $play = explode("@", $_SESSION['selected_plugins']);
			   foreach($play as $key => $value )
               {
               //echo "Key: $key; Value: $value<br />\n"; //for unit testing only
                if ($key>0)
                {
				//print "selected:".$value.";";    
				//set the list of checked plugins
				print "document.getElementById(\"$value\").checked=true;";	
				}
			   }
print "
}
addLoadEvent(pluginc_code);
</script>";     
}


?>
</table>
</p>
<!--//end of plugins choice-->


<!--//start of form close-->
<p >
<?php print "<input class=\"button\" name=\"Submit\" type=\"submit\" value=\"Install WordPress\"/></p>
</form>"; ?>
</p>
<!--//end of form close-->
</div>
</div>

<!--//end of form-->
	
	
<?php
//load hidden loading image
print "<img src=\"./images/loading6.gif\" style=\"display:none;\/>"; ?>

</body>
</html>